#include <stdio.h>
#include <math.h>
#include "Line.h"
#define ADDRESS_SIZE 32
#define offsetMask 0x0000000f
#define indexMask  0x000003f0
#define tagMask    0xfffffc00
#define setMask    0x000000f0
#define settagMask 0xffffff00
//#define setMask     

class Memory
{

    public:
    int memSize;
    int slots;
    int sets;
    int setBits;
    int blockSize;
    int blockBits;
    int tagBits;
    int settagBits;
    int offset;
    int indexBits;
    Line * cache;
    int count;
    int * mem;
    int readhits;
    int readmisses;
    int reads;
    int writehits;
    int writemisses;
    int writes;
    int mod;


    Memory()
    {
    }

    Memory(int rmsz, int sz, int blk, int mode)
    {
        mod = mode;
        readhits = 0;
        readmisses = 0;
        reads = 0;
        writehits = 0;
        writemisses = 0;
        writes = 0;
	count = 0;
	memSize = rmsz;
	slots = sz/blk;
	sets = slots / mode;
	setBits = log( sets );
	blockSize = blk;
	blockBits = log(blockSize);
	indexBits = log(slots) - blockBits;
	tagBits = ADDRESS_SIZE - blockSize - indexBits;
	settagBits = ADDRESS_SIZE - blockSize - setBits;
	mem = (int *)malloc(sizeof(int)*memSize);
	cache = (Line *)malloc(sizeof(Line)*slots);
	for( int i = 0; i < slots; i++ )
	{
		cache[i].valid = 0;
		cache[i].dirty = 0;
		cache[i].data = (int *)malloc(sizeof(int) * blockBits);
	}
	//fprintf(stdout,"Number of slots is: %d\nthe block size is %d\nNumber of blockBits is %d\nNumber of index Bits is %d\nNumber of tag bits is %d\nNumber of sets is %d\nNumber of setBits is %d\nNumber of Tag bits for set is %d", slots, blockSize,blockBits, indexBits, tagBits, sets, setBits, settagBits);
    }

    void loadInstruction( int instr, int i)
    {
	int offset = instr & offsetMask;
	int block = offset/4;
	int index = instr & indexMask;
	int tag = instr & tagMask;
	mem[i] = instr;
    }
    void storeByte(int byte)
    {


    } 

    void storeWord(int word, int val)
    {
	int set = (word & setMask) >> 4;
	int settag = (word & settagMask) >> 8;
	int index = (word & indexMask) >> 4;
	int tag = (word & tagMask) >> 10;
	int offset = word & offsetMask;
	int block = offset/4;
	int lru = 0;
	int valid = 0; 
	int dirty = 0;
	int tagsequal = 0;
	if(mod == 4)
	{
		//fprintf(stdout,"\n%08x\n%08x\n%08x\n", settag, set, offset);
		index = set;
		tag = settag;
		for(int i = 0; i < mod; i++ )
		{
			Line line = cache[index+i];
			if( line.valid == 0 )
			{
				index = index+i;
				break;
			}
			else
			{
				if(line.tag == tag)
				{
					index = index + i;
					break;
				}
				else
				{
					/*do LRU policy*/
					if( i + 1 == mod )
					{
						lru = 1;
						index += count%4;
					}
				}
			}
		}
	}
	if( cache[index].valid == 1 )
		valid = 1;
	if( cache[index].dirty == 1 )
		dirty = 1;
	if( cache[index].tag == tag )
		tagsequal = 1;
	int thiscase = 8*lru + 4*valid + 2*dirty + tagsequal;
	cache[index].set = set;
	//fprintf(stdout, "\ntag = %d, index = %d, offset = %d, block = %d\n", tag, index, offset,block);
	switch(thiscase)
	{
		case 0: fprintf(stdout, ""); 
		case 1: fprintf(stdout,""); 
			fprintf(stdout, " - Miss\n");
			for( int i = 0; i < blockBits; i++)
			{
				//cache[index].data[i] = ram[ramLookup%ramSize].data[i];	
				int inLook = cache[index].data[i]/4;
				if( inLook < 0)
					inLook = -inLook;
				if( inLook == 0 )
				    cache[index].data[i] = 0;
				else
				    cache[index].data[i] = mem[inLook%memSize];	
			}
			cache[index].tag = tag;
			cache[index].data[block] = val;	
			cache[index].valid = 1;	
			cache[index].dirty = 1;	
			writemisses++;
			break;
		case 2: fprintf(stdout,"Case 2- "); exit(0);break;
		case 3: fprintf(stdout,"Case 3- "); exit(0); break;
		case 4: fprintf(stdout,"");
			fprintf(stdout, " - Miss\n");
			cache[index].data[block] = val;	
			cache[index].tag = tag;
			cache[index].dirty = 1;	
			writemisses++;
			break;
		case 5: fprintf(stdout,""); 
			fprintf(stdout," - Hit\n");
			cache[index].data[block] = val;
			cache[index].dirty = 1;
			writehits++;
			break;
		case 6: fprintf(stdout,""); 
			fprintf(stdout," - Miss\n");	
			for(int i = 0; i < 4; i++)
			{
				int inLook = cache[index].data[i]/4;
				if( inLook < 0)
					inLook = -inLook;
				int tempCache = mem[inLook%memSize];
				mem[inLook%memSize] = cache[index].data[block];
				if( inLook == 0 )
				    tempCache = 0;
				else
				    tempCache = mem[inLook%memSize];	
				cache[index].data[i] = tempCache;
			}
			cache[index].tag = tag;
			cache[index].data[block] = val;
			writemisses++;
			break;
		case 7: fprintf(stdout,""); 
			fprintf(stdout, " - Hit\n");
			cache[index].data[block] = val;	
			writehits++;
			break;
		case 8:
		default:  
			fprintf(stdout," - Miss\n");	
			for(int i = 0; i < 4; i++)
			{
				int inLook = cache[index].data[i]/4;
				if( inLook < 0)
					inLook = -inLook;
				int tempCache = mem[inLook%memSize];
				mem[inLook%memSize] = cache[index].data[block];
				if( inLook == 0 )
				    tempCache = 0;
				else
				    tempCache = mem[inLook%memSize];	
				cache[index].data[i] = tempCache;
			}
			cache[index].tag = tag;
			cache[index].data[block] = val;
			writemisses++;
			break;
	}
	writes++;
	count++;
    } 



    int loadWord(int word)
    {
	int set = (word & setMask) >> 4;
	int settag = (word & settagMask) >> 8;
	int index = (word & indexMask) >> 4;
	int tag = (word & tagMask) >> 10;
	int offset = word & offsetMask;
	int block = offset/4;
	int valid = 0; 
	int dirty = 0;
	int tagsequal = 0;
	int lru = 0;
	if(mod == 4)
	{
		index = set;
		tag = settag;
		for(int i = 0; i < mod; i++ )
		{
			Line line = cache[index+i];
			if( line.valid == 0 )
			{
				index = index+i;
				break;
			}
			else
			{
				if(line.tag == tag)
				{
					index = index + i;
					break;
				}
				else
				{
					if( i + 1 == mod )
					{
						lru = 1;
						index += count%4;
					}
				}
			}
		}
	}
	if( cache[index].valid == 1 )
		valid = 1;
	if( cache[index].dirty == 1 )
		dirty = 1;
	if( cache[index].tag == tag )
		tagsequal = 1;
	int thiscase = 8*lru + 4*valid + 2*dirty + tagsequal;
	count++;
	reads++;
	cache[index].set = set;
	//fprintf(stdout, "\ntag = %d, index = %d, offset = %d, block = %d\n", tag, index, offset,block);
	switch(thiscase)
	{
		case 0: printf(""); 
		case 1: printf(""); 
			fprintf(stdout," - Miss\n");
			for(int i = 0; i < blockSize; i++ )
			{
				int inLook = cache[index].data[i]/4;
				if( inLook < 0)
					inLook = -inLook;
				if( inLook == 0 )
				    cache[index].data[i] = 0;
				else
				    cache[index].data[i] = mem[inLook%memSize];	
			}
			cache[index].tag = tag;
			cache[index].valid = 1;
			readmisses++;
			return cache[index].data[block];
			break;
		case 2: printf("READ Case 2- ");exit(0); break;
		case 3: printf("READ Case 3- ");exit(0); break;
		case 4: printf("");
			fprintf(stdout," - Miss\n");
			for(int i = 0; i < blockBits; i++)
			{
				int inLook = cache[index].data[i]/4;
				if( inLook < 0)
					inLook = -inLook;
				int tempCache = mem[inLook%memSize];
				if( inLook == 0 )
				    tempCache = 0;
				else
				    tempCache = mem[inLook%memSize];	
				mem[inLook%memSize] = cache[index].data[i];
				cache[index].data[block] = tempCache;
			}
			//ram[ramLookup%ramSize].valid = 1; //not necessary
			cache[index].tag = tag;
			cache[index].dirty = 0;
			readmisses++;
			return cache[index].data[block];
		case 5: printf("");
			fprintf(stdout," - Hit\n");
			return cache[index].data[block];
			readhits++;
			break;
		case 6: printf(""); 
			fprintf(stdout," - Miss\n");
			for(int i = 0; i < blockBits; i++)
			{
				int inLook = cache[index].data[i]/4;
				if( inLook < 0)
					inLook = -inLook;
				int tempCache = mem[inLook%memSize];
				if( inLook == 0 )
				    tempCache = 0;
				else
				    tempCache = mem[inLook%memSize];	
				mem[inLook%memSize] = cache[index].data[i];
				cache[index].data[block] = tempCache;
			}
			//ram[ramLookup%ramSize].valid = 1; //not necessary
			cache[index].tag = tag;
			cache[index].dirty = 0;
			readmisses++;
			return cache[index].data[block];
			break;
		case 7: printf(""); 
			fprintf(stdout," - Hit\n");
			readhits++;
			return cache[index].data[block];
			break;
		case 8:
		default: 
			fprintf(stdout," - Miss\n");
			for(int i = 0; i < blockBits; i++)
			{
				int inLook = cache[index].data[i]/4;
				if( inLook < 0)
					inLook = -inLook;
				int tempCache = mem[inLook%memSize];
				if( inLook == 0 )
				    tempCache = 0;
				else
				    tempCache = mem[inLook%memSize];	
				mem[inLook%memSize] = cache[index].data[i];
				cache[index].data[block] = tempCache;
			}
			cache[index+(count%4)].tag = tag;
			cache[index+(count%4)].dirty = 0;
			readmisses++;
			return cache[index+(count%4)].data[block];
			break;
	}
	return 0;
    }
    int loadByte(int byte)
    {
	return 0;
    }
    void printStats()
    {
	fprintf(stdout,"\n\n\n");
	fprintf(stdout,"OVERALL CACHE STATISTICS\n");
	fprintf(stdout,"Number of Read Hits - %d\n", readhits);
	fprintf(stdout,"Number of Read Misses - %d\n", readmisses);
	fprintf(stdout,"Total Number of Reads - %d\n", reads);
	fprintf(stdout,"Number of Write Hits - %d\n", writehits);
	fprintf(stdout,"Number of Write Misses - %d\n", writemisses);
	fprintf(stdout,"Total Number of Writes - %d\n", writes);
    }
    void printCache()
    {
	fprintf(stdout, "\n\n\nCache contents after %d cache accesses\n", count);
	fprintf(stdout, "---------------------------------------------------------------------\n");
	fprintf(stdout, "| VALID | DIRTY |   TAG    |\t\t\tDATA\t\t    |\n");
	fprintf(stdout, "---------------------------------------------------------------------\n\n");
	int tag = 0;
	int prevset = -1;
	for( int i = 0; i < slots; i++ )
	{
		if( cache[i].valid == 1)
		{
			tag = cache[i].tag;
			if( mod != 4 )
				fprintf(stdout, "SET %d\n",i);
			else if( cache[i].set != prevset )
			{
				fprintf(stdout, "SET %d\n",i);
				prevset = cache[i].set;
			}
			fprintf(stdout, "|   %d   |   %d   | %08x | %08x  %08x  %08x  %08x |\n", 1, cache[i].dirty, tag, cache[i].data[0], cache[i].data[1], cache[i].data[2], cache[i].data[3] ); 
		}
	}
	fprintf(stdout, "---------------------------------------------------------------------\n\n");
    }

    private:

    int log(int sz)
    {
	int i = 0;
	for( i = 0; i < sz/2; i++ )
	{
	    if( pow(2,i) == sz )
            {
                return i;
            }
        }
	return -1;
    }

};
