/*@author: Matthew Carr */
/*@Date: 4/21/04 */
/*@Desc: Mips Disassembler, and execution*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include "uMipsDisasm.h"
#include "Memory.h"

#define MAGIC 1718004673 
#define BYTESPERINSTRUCTION 4
#define BITSPERBYTE 8


// The code and comments below can be used or ignored... it is up to you.
// This is the way that I broke up the problem so that I could assemble the
// pieces in a clean and coherent manner, and it lets you reason (and debug) small
// pieces at a time.

// While you don't have to use any of this code, we do ask that you match our output
// format precisely

/////////////////////////////////////
// Headers
/////////////////////////////////////

// Memory should look like this:

// ----------------------
// 0x0
//
//
//          text segment
//
//
// textsize-4
// ----------------------
// textsize   <- GP points here
//
//
//          data segment
//
//
// textsize + datasize - 4
// ----------------------
// textsize + datasize
//
//          heap segment
//
//
// textsize + datasize + heapsize - 4
// ----------------------
// textsize + datasize + heapsize
//
//
//          stack segment
//
//
// textsize + datasize + heapsize + stacksize - 4 <- SP points here
// ----------------------




class uMipsExe
{
      public:
	//read the initalized portions of data and load them into mem
	int initmemory(FILE * f);
	//set the registers to thier starting values
	int initreg();

	//take the current state and then execute instr
	//return 1 if program is terminated
	//f is the output for system calls and errors
	//(used by run)
	int step(FILE* memory);

	//handle a system call, return 1 if syscall is exit else 0
	int my_syscall();

	//set the register value
	void writeReg(int m_regnum, unsigned m_regvalue);

	// dump the register state to a file
	int printstate();
	//constructor and destructor
	uMipsDisasm disasm;
	Memory theMem;
	  uMipsExe(int,char**);
	 ~uMipsExe();

	int file_offset;
      private:
	int memsize;
	//struct uMipsHeader header;
	//state
	int *memory;
	int *regs;
	int pc;

	//stats (not needed for this assignment but
	//they are included because some of the instruction defs 
	//use them
	int stores;
	int loads;
	int jumps;
	int arith;
	int branches;
	int branchesTaken;
	int syscalls;

};

const int MIPSREG_0 = 0;
const int MIPSREG_AT = 1;
const int MIPSREG_V0 = 2;
const int MIPSREG_V1 = 3;
const int MIPSREG_A0 = 4;
const int MIPSREG_A1 = 5;
const int MIPSREG_A2 = 6;
const int MIPSREG_A3 = 7;
const int MIPSREG_T0 = 8;
const int MIPSREG_T1 = 9;
const int MIPSREG_T2 = 10;
const int MIPSREG_T3 = 11;
const int MIPSREG_T4 = 12;
const int MIPSREG_T5 = 13;
const int MIPSREG_T6 = 14;
const int MIPSREG_T7 = 15;
const int MIPSREG_S0 = 16;
const int MIPSREG_S1 = 17;
const int MIPSREG_S2 = 18;
const int MIPSREG_S3 = 19;
const int MIPSREG_S4 = 20;
const int MIPSREG_S5 = 21;
const int MIPSREG_S6 = 22;
const int MIPSREG_S7 = 23;
const int MIPSREG_T8 = 24;
const int MIPSREG_T9 = 25;
const int MIPSREG_K0 = 26;
const int MIPSREG_K1 = 27;
const int MIPSREG_GP = 28;
const int MIPSREG_SP = 29;
const int MIPSREG_FP = 30;
const int MIPSREG_RA = 31;

const int MIPS_SYSCALL_PRINTINT = 1;
const int MIPS_SYSCALL_PRINTSTRING = 4;
const int MIPS_SYSCALL_READINT = 5;
const int MIPS_SYSCALL_READSTRING = 8;
const int MIPS_SYSCALL_EXIT = 10;
const int MIPS_SYSCALL_EXEC = 11;


/////////////////////////////////////
// Main
/////////////////////////////////////

void
usage()
{
}


int mod;
int
main(int argc, char **argv)
{

	//need to read the header, print the header,
	//init the memory, init the registers, and run the thing
	FILE * memory; // =(FILE*)malloc(sizeof(FILE));
	FILE * writeFile = fopen(argv[3],"w" );
	if( argc != 4)
	{
	    fprintf(stderr,"Incorrect Usage: %s [mode] [filename] [filename]\n", argv[0]);
	}
	if(errno == 2)
	{
	   fprintf(stderr,"%s: ", argv[0]); 
	   perror("");
	   exit(1);
        }
	int reroute = fileno(writeFile);
	int pipefd[2];
	int q = pipe(pipefd);
	if( q < 0)
	{
	    fprintf( stderr, "%s: Error printing to file\n",argv[0]);
	    perror("");
	    exit(1);
	}
	if( dup2( reroute, 1 ) != 1)
	{
	    fprintf(stderr, "%s: Error printing to file\n", argv[0]);
	    perror("");
	    exit(1);
	}
	uMipsExe emulator = uMipsExe(argc,argv);
	memory = emulator.disasm.loadFile(memory, argc, argv);
	emulator.file_offset = emulator.disasm.headersize;
	
	//emulator.disasm.printHeader();
	/*fprintf(stdout,"----------------------------------------\n");
*/
	emulator.initreg();
	mod = atoi( argv[1] );
	if( mod != 1 && mod != 4 )
	{
		fprintf(stderr,"%s: Error, please choose [mode] = 1 or 4.\n",argv[0]);
		perror("");
		exit(1);
	}
	int done = 0;
	emulator.initmemory(memory);
	fseek(memory, emulator.file_offset, SEEK_SET);
	int i = 0;
	int past = 5;
	while( done == 0 )
	{
	    done = emulator.step(memory);
	    i++;
	    if( emulator.theMem.count % 10 == 0 && emulator.theMem.count != 0 && emulator.theMem.count == past * 2 )
	    {
		emulator.theMem.printCache();
		past = emulator.theMem.count;
	    }
	}
/*	while( i != 30 )
	{
		done = emulator.step(memory);
		i++;
	}
*/
	emulator.theMem.printStats();
	fclose(memory);
	fclose(writeFile);
	/*test*/
	return 0;
}

/////////////////////////////////////
// Exe
/////////////////////////////////////

uMipsExe::uMipsExe(int argc, char** argv)
{
	pc = 0;
	disasm = uMipsDisasm();
	//file_offset = offset;
	regs = (int *) calloc(32, sizeof(int));
	for(int i = 0; i < 32; i++)
	{
	    regs[i] = 0;
	}
}

uMipsExe::~uMipsExe()
{
    free(regs);
}

// --- printing and headers ---------------------

int
uMipsExe::printstate()
{
    for(int i = 0; i < disasm.numregs; i++)
    {
	if( i <10 )
	    fprintf(stdout, " %d ( %s ) = %08x", i, disasm.regname(i), regs[i]);
	else
	    fprintf(stdout, "%d ( %s ) = %08x", i, disasm.regname(i), regs[i]);
	if( (i+1) % 4 == 0 )
	    fprintf(stdout, "\n");
	else
	    fprintf(stdout, "\t");
    }
    fprintf(stdout,"----------------------------------------\n");
    // print the state of the registers
    return 0;
}

int
uMipsExe::initmemory(FILE * f)
{
	memsize = ((disasm.textsize) + (disasm.datasize))/BYTESPERINSTRUCTION; //text size plus data size
	fprintf(stdout, "CACHE SIMULATOR TRACE\n\n");
	fprintf(stdout, "Cache Size - 1024, Associativity - %d, Blocksize - 16\n\n",mod);
	theMem = Memory(memsize, 1024, 16, mod);

	/*memory = (int *)malloc(sizeof(int)*memsize);
	*/
	for(int i = 0; i < memsize; i++ )
	{
	   /*memory[i] = disasm.loadMem(f); 
*/
	   theMem.loadInstruction(disasm.loadMem(f), i);
	}
	rewind(f);
	return 0;
	// initialize the memory (read text and data segments from executable)
}

int
uMipsExe::initreg()
{
	pc = disasm.entrypoint;
	regs[27] = disasm.datasize;
	regs[28] = disasm.textsize;
	regs[29] = disasm.datasize + disasm.textsize + disasm.stacksize + disasm.heapsize - 4; //(minus 4 for first instruction)
	return 0;
}

//set the register value
void 
uMipsExe::writeReg(int m_regnum, unsigned m_regvalue) 
{
    regs[m_regnum] = m_regvalue;
}
int
uMipsExe::step(FILE* mem)
{
	//returns 1 when the instruction executed is a halt or exit
	//otherwise returns 0
	/*the header info offset is 24*/
	int opcode = 0;
	int imm = 0;
	int immu = 0;
	int rs = 0;
	int rt = 0;
	int rd = 0;
	int func = 0;
	int shamt = 0;
	int target =0;
	int base = 0;
	bool wantPCIncrement = true;
	bool isDone = false;
	int temp = 0;

	line_struct * cache = (line_struct *)malloc(sizeof(line_struct));
	cache = disasm.loadInstruction(mem,cache, file_offset+pc);
	/*fprintf(stdout, "Executing %08x \t", pc);
	*/
/*
	disasm.printInstruction(cache);
*/
	opcode = cache->opcode;
	func = cache->func;
	imm = cache->immValue;
	immu = cache->immUValue;
	rs = cache->rs;
	rt = cache->rt;
	rd = cache->rd;
	shamt = cache->shamt;
	target = cache->target;
	base = cache->base;
	switch (opcode)
	{
	    case 0:
		switch (func)
		{

		    case 0:
			    arith++;
			    writeReg(rd, regs[rt] << shamt);	// sll sometimes NOP
			    break;

		    case 2:
			    arith++;
			    writeReg(rd, (regs[rt]) >> shamt);	// srl
			    break;

		    case 3:
			    arith++;
			    writeReg(rd, (regs[rt]) >> shamt);	// sra
			    break;

		    case 4:
			    arith++;
			    writeReg( rd, regs[rs] << (unsigned)regs[rt] );
			    break;

		    case 6:
			    arith++;
			    writeReg(rd, ((unsigned)regs[rs]) >> regs[rt]);	// srlv
			    break;

		    case 7:
			    arith++;
			    writeReg(rd, regs[rs] >> regs[rt]);	// srav
			    break;


		    case 8:	// jr
			    jumps++;
			    pc = regs[rs];
			    wantPCIncrement = false;
			    break;
		    case 9:	// jalr SHADY
			    jumps++;
			    writeReg( rd, pc + 4 );
			    pc = regs[rs];	
			    wantPCIncrement = false;
			    //WRITE ME
			    break;

		    case 0xC:	// syscall
			    syscalls++;
			    isDone = my_syscall();
			    break;


		    case 0x18:	// mult DONE
			    arith++;
			    writeReg( rd, regs[rs] * regs[rt] );
			    break;

		    case 0x1a:	// div DONE
			    arith++;
			    writeReg( rd, regs[rs]/regs[rt] );
			    break;

		    case 0x20:	// add DONE
			    arith++;
			    writeReg(rd, regs[rs] + regs[rt]);	
			    break;
		    case 0x22:	// sub
			    arith++;
			    writeReg( rd, regs[rs] - regs[rt]);
			    break;

		    case 0x24:	// and DONE
			    arith++;
			    writeReg( rd, regs[rs] & regs[rt] );
			    break;
		    case 0x25:	// or
			    arith++;
			    writeReg( rd, regs[rs] | regs[rt] );
			    break;
		    case 0x26:	// xor
			    arith++;
			    writeReg( rd, regs[rs] ^ regs[rt] );
		    case 0x2a:	// slt
			    arith++;
			    if( regs[rs] < regs[rt] )
				writeReg( rd, 1);
			    else
				writeReg( rd, 0);
			    break;
		    default:
			    fprintf(stderr,"Tried to execute unimplemented instruction\nExiting...\n");
			    exit(2);
			break;    //unimplemented_instr(instr);
		}
		break; //break from switch on func

	case 2:	// j 
		jumps++;
		pc = target;
		wantPCIncrement = false;
		break;

	case 3: //jal DONE (MAYBE CHECK -=4 part)
		jumps++;
		regs[MIPSREG_RA] = (pc+BYTESPERINSTRUCTION);
		pc = target;	
		wantPCIncrement = false;
		//regs[MIPSREG_SP]-= BYTESPERINSTRUCTION;
		break;
	case 4:	// beq shady
		if( regs[rt] == regs[rs] )
		{
		    jumps++;
		    wantPCIncrement = false;
		    pc+= BYTESPERINSTRUCTION + (imm << 2); /*maybe should be imm << 2 */
		}
		//WRITE ME
		break;
	case 5:	// bne SHADY
		if( regs[rt] != regs[rs] )
		{
		    jumps++;
		    wantPCIncrement = false;
		    pc+= BYTESPERINSTRUCTION + (imm <<2); /*maybe should be imm << 2*/
		}
		break;

	case 6:	// blez
		arith++;
		if( regs[rs] <= 0)
		{
		    wantPCIncrement = false;
		    pc+=BYTESPERINSTRUCTION + (imm <<2); /*maybe should be imm << 2 */
		}
		break;
	case 7:	// bgtz
		//WRITE ME
		arith++;
		if( regs[rs] < 0 )
		{
		    wantPCIncrement = false;
		    pc+=BYTESPERINSTRUCTION + (imm << 2); /*maybe should be imm <<2 */
		}
		break;
	case 8:	// addi DONE
		arith++;
		writeReg( rt, regs[rs] + imm ); 
		break;
	case 0xc:	// andi
		arith++;
		writeReg( rt, regs[rs] & imm );
		break;
	case 0xd:	// ori
		arith++;
		writeReg(rt , regs[rs] | imm);
		break;
	case 0xe: 	// xori
		arith++;
		writeReg(rt , regs[rs] ^ imm);
		break;

	case 0xa:	// slti
		arith++;
		if (regs[rs] < imm)
			writeReg(rt, 1);
		else
			writeReg(rt, 0);
		break;

	case 0x10:	// rfe/mfc0/mtc0
		if (func == 24){	
			// halt
			isDone = 1;
		} else {
			    fprintf(stderr,"Tried to execute unimplemented instruction\nExiting...\n");
			    exit(2);
		}
		break;

	case 0x20:	// lb
		/*writeReg( rt, memory[ ((regs[rs] + imm)/BYTESPERINSTRUCTION)%memsize]);
*/
		fprintf(stdout,"Read Byte access to %08x", regs[base] + imm);
		writeReg(rt, theMem.loadWord((regs[base] + imm)) & 0x000000ff );
		break;

	case 0x23:	// lw DONE
		//printf("loading from line # %d\n",((regs[base] + imm)/BYTESPERINSTRUCTION)%memsize );
		/*writeReg(rt, memory[((regs[base] + imm)/BYTESPERINSTRUCTION)%memsize]);
		*/
		fprintf(stdout,"Read Word access to %08x", regs[base] + imm );
		writeReg(rt, theMem.loadWord((regs[base] + imm)) );
		break;

	case 0x28:	// sb
		temp = regs[rt] & 0x000000ff;
		fprintf(stdout,"Write Byte access to %08x", regs[base] + imm);
		theMem.storeWord((regs[base] + imm), temp);
/*
		memory[((regs[rt] + imm)/BYTESPERINSTRUCTION)%memsize] = temp;
*/
		break;

	case 0x2b:	// sw DONE 
		//(regs[base] + imm)/BYTESPERINSTRUCTION;
		//printf("storing on line # %d\n",((regs[base] + imm)/BYTESPERINSTRUCTION)%memsize );
		fprintf(stdout,"Write Word access to %08x", regs[base] + imm);
		theMem.storeWord((regs[base] + imm), regs[rt]);
		/*memory[((regs[base] + imm)/BYTESPERINSTRUCTION)%memsize] = regs[rt];
*/
		//WRITE ME
		break;

	default: //not implemented
		fprintf(stderr,"Tried to execute unimplemented instruction\nExiting...\n");
		exit(2);
		break;

    }


	//update the pc
	if(wantPCIncrement)
	    pc+=BYTESPERINSTRUCTION;
	//make sure register 0 is still 0!
	regs[0] = 0;
/*
	printstate();
*/

    return isDone;


}



int
uMipsExe::my_syscall()
{
	//when there is a system call, the id of the syscall is 
	//stored in V0, and the argument is stored in A0
	if( regs[MIPSREG_V0] == MIPS_SYSCALL_PRINTINT )
	{
	    fprintf(stderr,"%d\n", regs[MIPSREG_A0]);
	    return 0;
	}
	else if( regs[MIPSREG_V0] == MIPS_SYSCALL_PRINTSTRING )
	{
	    /*char* st = (char*)memory[regs[MIPSREG_A0]];*/
	    char* sr = (char*)regs[MIPSREG_A0];
	    fprintf(stderr,"%s or %s\n",sr);
	    return 0;
	}
	else if( regs[MIPSREG_V0] == MIPS_SYSCALL_EXIT )
	{
	    return 1;
	}
	return 0;
	
	// write code here to check what system call it is and take the necessary action
	// e.g., print an integer (to stdout), print a string (to stdout), or exit
}
