/*@author: Matthew Carr */
/*@Date: 4/21/04 */
/*@Desc: Mips Disassembler*/

/*STRUCTURE FOR EACH INSTRUCTION LOADED FROM THE FILE*/
class line_struct {
public:
    int type;
    char* op;
    int opcode;
    int func;
    char* reg1;
    int rd;
    char* reg2;
    int rs;
    char* reg3;
    int rt;
    int immValue;
    int immUValue;
    int shamt;
    int base;
    int jtarget;
    int target;
    int twentyBitValue;
    int twentySixBitValue;
};
