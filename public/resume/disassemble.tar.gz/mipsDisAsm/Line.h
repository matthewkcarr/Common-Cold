/*@author: Matthew Carr */
/*@Date: 4/21/04 */
/*@Desc: Mips Disassembler*/

/*STRUCTURE FOR EACH INSTRUCTION LOADED FROM THE FILE*/
class Line {
public:
bool valid;
bool dirty;
int tag;
int * data;
int set;
};
