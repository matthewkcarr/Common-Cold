/*@author: Matthew Carr */
/*@Date: 4/21/04 */
/*@Desc: Mips Disassembler*/

/*INCLUDES*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include "line_struct.h"

#define MAGIC 1718004673 
#define BYTESPERINSTRUCTION 4
#define BITSPERBYTE 8
/*

/////////////////////////////////////
// Headers
/////////////////////////////////////
*/


/*CLASS THAT HANDLES THE DISASSEMBLY OF EXE FILE AFTER ITS LOADED*/
class uMipsDisasm
{
      public:

	/*CONSTRUCTOR*/
	uMipsDisasm();

	/*LOAD A BINARY INSTURCTION*/
	void loadBinary(unsigned int proc, line_struct * store);
	/*IF INSTURCTION IS SIGN EXENTED OR NOT -RETURNS 1 if it is*/
	int signextended(char* op);

	//returns a pointer to a string that
	//maps the number to whatever the name
	//of the feild is. A new string is NOT
	//allocated for you, so don't delete the
	//copy that is returned.
	char *regname(int regnum);
	char *opname(int opnum);
	/*OPTYPE TAKES THE OP INT OF THE LOADED INSTURCTION AND FIGURES OUT ITS R-I-J type*/
	int optype(int opnum);
	char *funcname(int funcnum);
	/*FUNCTYPE TAKES THE FUNC INT OF THE LOADED INSTURCTION AND FIGURES OUT ITS R-I-J type*/
	int functype(int funcnum);
	/*OUTPUTS BINARY REPRESENTATION OF AN INT*/
	char* itobsh(int n, char* ps)
	{
	    int i;
	    static int size = 8 * sizeof(int);

	    for( i = size -1; i >= 0; i--, n>>=1 )
	    {
		ps[i] = (01 & n) + '0';
	    }
	    ps[size] = '\0';
	    return ps;

	}
	int swap_endian(unsigned int x)
	{
	    int result = 0;
	    int mask2 = 0377;
	    for(int i = 0; i < BYTESPERINSTRUCTION; i++)
	    {
		result |= (x & mask2);
		x >>= 8;
		if( i+1 != BYTESPERINSTRUCTION )
		    result <<= BITSPERBYTE;
	    }
	    return result;
	}
	//given an intruction, disasemble the instruction
	//and write the result in buf.  Note that buf
	//should be big enough for the largest string
	//WRITE ME
	void buff(int dtext,int memAddr);
	int get_numregs() { return numregs; }
	void checkfile(int c);
	void printInstruction(line_struct *);
	void printHeader();
	FILE* loadFile(FILE*, int, char**);
	line_struct* loadInstruction( FILE *, line_struct *,long );
	int loadMem( FILE * mem );

	int numregs;
	int numops;
	int numfuncs;
	int BACKWARDS;
	//uMipsHeader
	int headersize; //header size in bytes
	int magic_num;	//Magic Number
	int textsize;	//Text segment size in bytes
	int datasize;	//Data segment size in bytes
	int stacksize;	//Stack size in bytes
	int heapsize;	//Heap size in bytes
	int entrypoint;	//Entry point (first instruction to execute)

	char **regname_array;
	char **opname_array;
      int *optype_array;
	int *functype_array;
      char **funcname_array;


};
