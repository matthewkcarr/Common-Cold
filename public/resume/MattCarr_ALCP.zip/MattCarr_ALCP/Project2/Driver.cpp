// Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr
// Purpose: Driver.cpp tests the Parser and Section Objects to ensure
//          that they work correctly.  This file will create a parser object
//          which will in turn read in a file passed in from the command line.
//          Next it will read from and write to the header section's key 
//          value's and save any changes to the file.
#include <iostream>
#include <string>

#include "Parser.h"

using namespace std;

/* Test will let us know if an expression failed or not
 */
void Test( bool val)
{
   if( val )
   {
      cout << "Test Passed." << endl;
      return;
   }
   cout << "Test Failed." << endl;
}

/* Main will process the filename taken from the command line
 * and create a parser object with it. Next it will test some of the
 * public functions available from the Parser class.
 */
int main(int argc, char ** argv)
{
   if( argc != 2 )
   {
      cerr << "USAGE:  " << argv[0] << " [filename]" << endl;
      exit(1);
   }
   aParser* parser = new aParser(argv[1]);
   //Test the Get functions
   string project = parser->GetString("header", "project");
   cout << "[header] - > project: " << project << endl;
   float budget = parser->GetFloat("header", "budget");
   cout << "[header] - > budget: " << budget << endl;
   int accessed = parser->GetInt("header", "accessed");
   cout << "[header] - > accessed: " << accessed << endl;
   string description = parser->GetString("meta data", "description");
   cout << "[meta data] - > description: " << description << endl;
   string correction = parser->GetString("meta data", "correction text");
   cout << "[meta data] - > correction text: " << correction << endl;
   string strBudget = parser->GetString("trailer", "budget");
   cout << "[trailer] - > budget: " << strBudget << endl;

   //Test the Set Functions
   parser->SetInt("header", "accessed", 4000);
   parser->SetFloat("header", "budget", 5600.5);
   parser->SetString("trailer", "budget", "We are not nearly out of budget just yet.");
   parser->SetString("meta data", "correction text", "Tediously\nIs\nAn\nApt Word");
   delete parser; 

   //Check to see if the values stick after they were set 
   //(Could just look at the file, but this is more automated)
   aParser* stuck = new aParser(argv[1]);
   Test(stuck->GetInt("header", "accessed") == 4000);
   Test(stuck->GetFloat("header", "budget") == 5600.5);
   Test(stuck->GetString("trailer", "budget").compare("We are not nearly out of budget just yet.") == 0);
   Test(stuck->GetString("meta data", "correction text").compare("Tediously\nIs\nAn\nApt Word") == 0);
   delete stuck;
}
