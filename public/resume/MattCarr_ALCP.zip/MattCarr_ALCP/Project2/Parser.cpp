// Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr
// Purpose: The definition and functionality of the Parser
// object is contained here. This class allows the user to create
// a parser object that will read and write to a file that is expected to be
// in a specified format. See the Driver.cpp class and Parser.h 
// for usage examples of this class. Also see AlDocs/Readme.Txt for more info.

#include "Parser.h"


/* Constructor Object. Reads in a c-style string filename and returns
 * a Parser Object.
 */
aParser::aParser(char* fileName)
:fFileName(fileName)
{
   fstream fFile;
   fFile.open(fileName, fstream::in);
   if( ! fFile.is_open() )
   {
      cerr << "ERROR: File " << fileName 
           << " could not be opened. Exiting..." << endl;
      exit(1);
   }
   ReadFile(fFile);
}

/* This function forms the main skeleton for reading the file 
 * line by line.
 */
void aParser::ReadFile(fstream& fFile)
{
   string sLine;
   aSection currSection("");
   string currKey("");
   string strSection("");
   bool lineFinished = false;
   while(getline(fFile,sLine))
   {
      if(sLine.empty())
      {
         // Ignore empty line
      }
      else
      {
         lineFinished = ProcessSection(sLine, currSection, strSection);
         if(lineFinished)
         {
            continue;
         }
         ProcessKey(sLine, currSection, currKey); 
      }
   }
   AddSection(currSection.GetName(), currSection);
   fFile.close();
}

/* ProccessSection takes a single line (string sLine), the current
 * Section object, and the section header string name being parsed.
 * The method is used by ReadFile() and determines whether or not
 * the current line is a header, and whether or not the Section
 * is ready to be stored in the class member's hash (fSectionHash).
 * It returns true if the current line was in fact a section so that
 * ReadFile() may continue to the next line without looking for keys.
 * Otherwise it returns false and ReadFile() will look for a key/value
 * pair instead.
 */
bool aParser::ProcessSection(string sLine, 
                             aSection& currSection, 
                             string& strSection)
{
   int openBracketIdx = sLine.find("[");
   int closBracketIdx = sLine.find("]");
   if(closBracketIdx > 0) 
   {
      CheckColumnZero(sLine, '[');
      string prevSection = strSection;
      strSection  = sLine.substr(openBracketIdx + 1, closBracketIdx - 1);
      //If beNice is defined then sometimes there is a trailing bracket
      //that doesn't belong there. So this section removes it.
#ifdef qBeNice
      if( strSection[strSection.length() -1] == ']')
      {
         strSection = strSection.substr(0, strSection.length() - 1);
      }
#endif
      StripBlanks(strSection);
      if( prevSection.compare("") != 0)
      {  /*try to store the section in the hash if all of the
           key value pairs have been created in it*/
         if(!AddSection(prevSection, currSection)) 
         {
            return true;
         }
      }
      //prepare the next section so that keys and values may be stored.
      currSection = aSection(strSection); 
      return true;
   }
   return false;
}

/* ProcessKey takes in the current line from ReadFile(), the current section
 * being worked with, and the current key that is being used (in case the key
 * has multiple lines.  It stores the key in the current section.
 */
void aParser::ProcessKey(string sLine, aSection& currSection, string& currKey)
{
   string currValue("");
   int keyEndIdx = sLine.find_first_of(":");
   if( keyEndIdx == 0)
   {
      cerr << "ERROR: You cannot have a key with an empty value." << endl;
      exit(1);
   }
   else if( keyEndIdx > 0 ) /*found a new key so store it*/
   {
      CheckColumnZero(sLine, ' ');
      currKey  = sLine.substr( 0, keyEndIdx ); // Extract key string
      StripBlanks(currKey);
      currValue  = sLine.substr( keyEndIdx + 1, sLine.length() - 1); 
      StripBlanks(currValue);
      currSection.Add(currKey, currValue); 
   }
   else /*(handle new line that has a value without a key so stick 
          it onto the previous key */
   {
      StripBlanks(sLine);
      string hashedValue = currSection.GetValue(currKey);
      currValue = hashedValue + "\n" + sLine;
      currSection.Set(currKey, currValue); 
   }
}

/* CheckColumnZero checks the current line to see if 
 * column zero of the string contains the correct character
 * depending on whether it's a key or a header. When qBeNice
 * is defined then this method will only declare an ERROR, 
 * otherwise it will declare the ERROR and exit the program
 */
void aParser::CheckColumnZero(string line, char ch)
{
   if('[' == ch)
   {
      if('[' != line[0])
      {
         cerr << "ERROR: You must start a header with '['"
              << " in column zero of a line." << endl;
#ifndef qBeNice
         exit(1);
#else
         cerr << "Ignoring..." << endl;
#endif
      }
   }
   else if(' ' == ch)
   {
      if(' ' == line[0])
      {
         cerr << "ERROR: You must start a key "
              << "in column zero of a line." << endl;
#ifndef qBeNice
         exit(1);
#else
         cerr << "Ignoring..." << endl;
#endif
      }
   }
}

/* Save() iterates through the Parser fSectionHash
 * and saves all of the headers, keys, and values to
 * the file.
 */
void aParser::Save()
{
   ofstream file(fFileName);
   //key:value hash that is obtained from fSectionHash
   map<string, string> hash;
   map<string, aSection>::iterator iter;
   map<string, string>::iterator i;
   aSection section;
   //for each section obtain the key:value hash so we can iterate through it
   //and print out the header name to the file.
   for(iter = fSectionHash.begin(); iter != fSectionHash.end(); ++iter)
   {
      file << "[" << iter->first << "]" << endl;
      section = iter->second;
      hash = section.GetHash();
      //iterate through each key:value so we can print it out to the file.
      for(i = hash.begin(); i != hash.end(); ++i)
      {
         file << i->first << ": " << i->second << endl;
      }
      file << endl;
   }
   file.close();
}

/* Destructor - Saves the file in case any changes were made
 */
aParser::~aParser()
{
   //Save(); --File is saved each time a Set function is called.
   //files are automatically closed, and this class contains 
   //no pointers or new objects to worry about.
}

/* SetFloat will place an float value into the hash given the string
 * sectionName (header), and the string key. This will change the file
 * once the parser object has been destroyed.
 */
void aParser::SetFloat(string sectionName, string key, float newValue)
{
   ostringstream myStream;
   if( myStream << newValue << flush )
   {
      fSectionHash[sectionName].Set(key, myStream.str());
      Save(); //personally I think this should occur once when
              //the parser object file is deleted... but
              //the requirements specify that each Set value
              //is to save the file atomically.
   }
   else
   {
      cerr << "ERROR: Conversion to string failed in "
           << "Parser.cpp::SetFloat(string,string,float): Exiting." << endl;
      exit(1);
   }
}

/* SetInt will place an int value into the hash given the string
 * sectionName (header), and the string key. This will change the
 * file once the parser object has been destroyed.
 */
void aParser::SetInt(string sectionName, string key, int newValue)
{
   ostringstream myStream;
   if( myStream << newValue << flush )
   {
      fSectionHash[sectionName].Set(key, myStream.str());
      Save(); //personally I think this should occur once when
              //the parser object file is deleted... but
              //the requirements specify that each Set value
              //is to save the file atomically.
   }
   else
   {
      cerr << "ERROR: Conversion to string failed in "
           << "Parser.cpp::SetInt(string,string,int): Exiting." << endl;
      exit(1);
   }
}
/* SetString will place a string value into the hash given the string
 * sectionName (header), and the string key. This will change the 
 * file once the parser object has been destroyed.
 */
void aParser::SetString(string sectionName, string key, string newValue)
{
   fSectionHash[sectionName].Set(key, newValue);
   Save(); //personally I think this should occur once when
           //the parser object file is deleted... but
           //the requirements specify that each Set value
           //is to save the file atomically.
}

/* AddSection determines whether or not the current section 
 * being parsed is already stored in the hash. If it is not, then
 * it stores a new section in the hash for us and returns true
 * otherwise it will
 * send us an error and exit (depending on whether qBeNice is 
 * defined or not. string sectionName is the name of the header,
 * and aSection section is the section being proposed for storage
 * in the hash.
 */
bool aParser::AddSection(string sectionName, aSection section)
{
   aSection stored = fSectionHash[sectionName];
   //cout << stored.GetName() << " == " << sectionName << endl;
   if( stored.GetName().compare(sectionName) == 0 )
   {
      cerr << "ERROR: You are not allowed to have two Section" 
           << " names that are the same!" << endl;
      cerr << "ERROR: You are trying to use \"" << sectionName 
           << "\" twice" << endl;
#ifndef qBeNice
      exit(1);
#else
      cerr << "Ignoring..." << endl;
      return false;
#endif
   }
   fSectionHash[sectionName] = section;
   return true;
}

/* GetInt will return the int value of a key contained
 * in the specified header. string sectionName is the name
 * of the header, and string key is the name of the key where
 * the value is stored.
 */
int aParser::GetInt(string sectionName, string key)
{
   int i = 0;
   aSection section = fSectionHash[sectionName];
   if(StringTo<int>(section.GetValue(key), i))
   {
      return i;
   }
   cerr << "ERROR: GetInt in Parser.cpp failed" 
        << ", it's possible that " << sectionName << " or "
        << key << " does not exist" << endl;
#ifndef qBeNice
   exit(1);
#endif
   return 0;
}

/* GetFloat will return the float value of a key contained
 * in the specified header. string sectionName is the name
 * of the header, and string key is the name of the key where
 * the value is stored.
 */
float aParser::GetFloat(string sectionName, string key)
{
   float flt = 0.0;
   aSection section = fSectionHash[sectionName];
   if(StringTo<float>(section.GetValue(key), flt))
   {
      return flt;
   }
   cerr << "ERROR: GetFloat in Parser.cpp failed" 
        << ", it's possible that " << sectionName << " or "
        << key << " does not exist" << endl;
#ifndef qBeNice
   exit(1);
#endif
   return 0;
}

/* GetString will return the string value of a key contained
 * in the specified header. string sectionName is the name
 * of the header, and string key is the name of the key where
 * the value is stored.
 */
string aParser::GetString(string sectionName, string key)
{
   aSection section = fSectionHash[sectionName];
   return section.GetValue(key);
}

/* StripBlanks will remove any white space at the beginning
 * and end of a string.
 */
void aParser::StripBlanks(string& StringToModify)
{
   if(StringToModify.empty())
   { 
      return;
   }
   int startIndex = StringToModify.find_first_not_of(" ");
   int endIndex = StringToModify.find_last_not_of(" ");
   string tempString = StringToModify;
   StringToModify.erase();
   StringToModify = tempString.substr(startIndex, (endIndex-startIndex+ 1) );
}

/* StringTo converts string s to another type t using the sstream library.
 * If the conversion is successful it returns true
 * otherwise, false.
 */
template <class T> bool aParser::StringTo(const string s, T& t)
{
   istringstream myStream(s);
   if (myStream >> t)
   { 
      return true;
   }
   else
   {   
      return false;
   }
}

