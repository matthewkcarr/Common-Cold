/ Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr

Compilation and Execution:
From the command line run
./make
./parse testfile.txt

Usage: parse <filename>
where <filename> contains
[header]
key: value
[header2]
key: value

Purpose: This program reads <filename> from the command line and creates
a Parse data structure containing each header and key/value pair.  Each header
is parsed into a Section (Section.cpp) object.  In Section.cpp each key and value are stored in a hash (map) object. All fields may be read or changed and written back to the file.  
Eg.  parse->SetInt("header", "key", 5) will change <filename> to
[header]
key: 5
[header2]
key: value

See Driver.cpp for more examples on usage.

Testing:
This program has been tested for and will compile on g++ (GCC) 3.4.5 on Linux
Kernel 2.6.16.16 and g++ (GCC) 3.3.3 on Linux Kernel 2.6.5-1.358

List of Files and Description:

Parser.cpp
-The main object implementation containing the file handler and section 
 hash (map) object. 

Parser.h
-The header file for the Parser Object with descriptions of each method and 
 class member variables.

Section.cpp
-The Section object that contains key/value pairs.

Section.h
-Section header file containing descriptions of methods and class member variables.

Driver.cpp
-A class to test the Parser and Section objects.

Makefile
-Compiles the program by running "make" at the prompt.  The path settings used in the Makefile are relative to the makefile's current directory. 

Note: Near the top of Parser.h and Section.h is a global definition 
      #define qBeNice
      This definition allows more flexibility in parsing the input file 
      than specified in the requirements.  For example, if a key or header
      is not located in the first column of the line an ERROR message is
      sent to cerr and the program continues smoothly. Furthermore if a
      header or key is replicated then the default action is to give an
      ERROR message and keep the FIRST DEFINED header or key/value.
      However, if qBeNice is not defined then the program will exit 
      after the ERROR message.  The default is set to "be nice" (#define
      qBeNice) in each file. 
