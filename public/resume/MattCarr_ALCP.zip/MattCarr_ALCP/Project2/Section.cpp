// Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr
// Purpose: The definition and functionality of the Section
// object is contained here. This class allows the user to create
// a section object from a header string, and then store key value pairs.
// in a specified format. See Parser.cpp and Section.cpp for examples.
// Also see AlDocs/Readme.Txt for more info.

#include "Section.h"

/* Default constructor makes a section with an empty string for a name.
 * This helps determine whether or not we are working with a 
 * section (header) from the file or not.
 */
aSection::aSection()
:fSectionName("")
{
}

/* Constructor that names the section given a string telling the class
 * what the header(section) name is as determined from the file.
 */
aSection::aSection(string sName)
:fSectionName(sName)
{
}

/* Return the value associated with the string key located
 * in the hash of key value pairs within this class
 */
string aSection::GetValue(string key)
{
   return fHash[key];
}

/* Add will place a new key value pair in the hash
 * stored within this class. If one already exists
 * print an error (and exit unless qBeNice is defined.)
 */
void aSection::Add(string key, string value)
{
   if( fHash[key].compare("") != 0)
   {
      cerr << "ERROR: You are not allowed to have two keys with the same"
           << " name!" << endl;
      cerr << "ERROR: You are trying to use \"" << key << "\" twice" 
           << endl;
#ifndef qBeNice
      exit(1);
#else
      cerr << "Ignoring..." << endl;
      return;
#endif
   }
   fHash[key] = value;
}

/* Set will replace the current string value currently
 * stored in the key location of the hash.
 */
void aSection::Set(string key, string value)
{
   fHash[key] = value;
}

/* GetName will return the name of this section.
 */
string aSection::GetName() const
{
   return fSectionName;
}

/* SetName will set the name of this section.
 */
void aSection::SetName(string name)
{
   fSectionName = name;
}

/* GetHash will return the hash of key value pairs 
 * stored in this section object.
 */
map<string,string> aSection::GetHash() const
{
   return fHash;
}

/* operator== overloaded so that two sections may be
 * compared to each other. They are compared by testing
 * if the names of the sections are the same.
 */
bool aSection::operator==(const aSection section) const
{
   return this->GetName().compare(section.GetName()) == 0;
}

/* operator= overloaded so that one section may be
 * copied to another. The name and the hash of the
 * section is copied. 
 */
bool aSection::operator=(const aSection section)
{
   this->fSectionName = section.GetName();
   this->fHash = section.GetHash();
   return true;
}
