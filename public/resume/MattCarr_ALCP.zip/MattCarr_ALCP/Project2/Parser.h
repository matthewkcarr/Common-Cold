// Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr
// Purpose: The definitions of the Parser
// object is contained here. This class allows the user to create a
// parser object that will read and write to a file that is expected to be
// in a specified format. 

#ifndef h_Parser
#define h_Parser
#define qBeNice //Define qBeNice
                //so that if two sections have the same name then 
                //we won't exit the program, but instead just keep
                //the first defined section and disregard the second.

#include <iostream>
#include <fstream>
#include <map>
#include <string>

#include "Section.h"

using namespace std;


class aParser
{
   char* fFileName; //input file name
   map<string, aSection> fSectionHash; //hash of Section Objects

   public:
      /*Create a Parser Object by passing in a c-style string filename
       * eg. aParser parser = new aParser("testfile.txt");
       */
      aParser(char*);
      /* Destroy Parser Object
       */
      ~aParser();

      /* GetInt will return the int value given
       * the string section(header) name and the string key
       * eg. int i = parser->GetInt("header","key");
       */
      int GetInt(string, string);
      /* GetFloat will return the float value given
       * the string section(header) name and the string key
       * eg. float f = parser->GetFloat("header","key");
       */
      float GetFloat(string, string);
      /* GetString will return the string value given
       * the string section(header) name and the string key
       * eg. string s = parser->GetString("header","key");
       */
      string GetString(string, string);
      /* SetInt will change the value found in 
       * string header, string key to int value.
       * Any changes Set with this function will be 
       * saved to the file.
       */
      void SetInt(string, string, int);
      /* SetFloat will change the value found in 
       * string header, string key to float value.
       * Any changes Set with this function will be 
       * saved to the file.
       */
      void SetFloat(string, string, float);
      /* SetString will change the value found in 
       * string header, string key to string value.
       * Any changes Set with this function will be 
       * saved to the file.
       */
      void SetString(string, string, string);

   private:
      /* AddSection will add a new section to
       * the section hash fSectionHash
       */
      bool AddSection(string, aSection);
      /* Save will commit all changes used by
       * SetInt, SetFloat, SetString to file.
       */
      void Save();
      /* ReadFile reads a file stream passed in
       * to the constructor
       */
      void ReadFile(fstream&);
      /* CheckColumnZero will make sure that 
       * column 0 for headers and keys are 
       * correct.
       */
      void CheckColumnZero(string, char);
      /* ProcessSection will determine if a line from
       * the file is in fact a header or not, and it will
       * also store the section in the fSectionHash once
       * the section contains all of its key/value pairs.
       */
      bool ProcessSection(string, aSection&, string&);
      /* ProcessKey will determine if a line from
       * the file is in fact a key or not, and it will
       * also store the key/value pair in the current section.
       */
      void ProcessKey(string, aSection&, string&);
      /* StripBlanks will remove any whitespace from both ends
       * of a string.
       */
      void StripBlanks(string&);
      /* StringTo makes each GetInt, GetFloat ... generalized
       * so that code is not repeated.
       */
      template <class T> bool StringTo(const string, T&);
};
#endif /*h_Parser*/
