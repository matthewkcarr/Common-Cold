// Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr
// Purpose: The definition and functionality of the FixedPoint32
// object is contained here. This class allows the user to create
// a fixed point encoded object that is 32 bits long. See the 
// Driver.cpp class for usage examples. See AlDocs/Readme.Txt for more info.

#include "FixedPoint32.h"

/* Largest possible number to fit here is around 65535.999939, 
 * least is -65535.999939 - largest character size is set to 40
 * characters including sign and period to give plenty of room
 */
const float kLargestSize(65535.999939);
const int kMaxDigits(40);
const int kFixedSize(32); //Number of binary digits available 
const int kDecSize(15);   //Number of decimal binary digits available 
const int kIntSize(16);   //Number of int binary digits available 


/* Initialize fDec[] and fInt[] so no garbage will be stored there 
 */
void aFixedPoint32::Initialize()
{
   fDec = new bool[kDecSize];      //binary array for decimal digits
   fInt = new bool[kIntSize];      //binary array for integer digits
   fNegative = 0;
   for(int i=0; i< kDecSize; ++i)
   {
      fDec[i] = 0;
   }
   for(int i=0; i< kIntSize; ++i)
   {
      fInt[i] = 0;
   }
}

/* Ensure that our constructor will throw an error if
 * the user of the class is trying to 
 * create some larger or greater than it should
 */
void aFixedPoint32::CheckBounds(float floatNum)
{
   if(floatNum > kLargestSize)
   {
      cerr << "ERROR: You may not create a fixed point";
      cerr << " number larger than " << kLargestSize << endl;
#ifndef qDebug
      exit(1);
#endif
   }
   if((-1*floatNum) > kLargestSize)
   {
      cerr << "ERROR: You may not create a "; 
      cerr << "fixed point number less than -" << kLargestSize << endl;
#ifndef qDebug
      exit(1);
#endif
   }
}

/* Creates a Fixed Point Encoding Object by seperating the
 * sign bit, int bits, and decimal bits
 * from the packed unsigned int and stores the information
 * in  binary arrays fInt and fDec.
 */
aFixedPoint32::aFixedPoint32(unsigned int packedNum)
{
   Initialize();
   if((0x80000000 & packedNum) == 0x80000000)
   {
      fNegative = 1;
   }
   unsigned int upper = (0x7FFF8000 & packedNum) >> 15;
   unsigned int lower =  0x00007FFF & packedNum;
   IntToBin(upper);
   unsigned int flag = 0x00006000;
   for (int i=0; i< kDecSize; ++i)
   {
      fDec[i] = lower & flag;
      flag >>= 1;
   }
}

/* Does the same as the above but uses a float as its initial value 
 */
aFixedPoint32::aFixedPoint32(float floatNum)
{
   CheckBounds(floatNum);
   Initialize();
   float splitFloat[2];
   if (floatNum < 0)
   {
      floatNum *= -1;
      fNegative = 1;
   }
   Split(floatNum, splitFloat);
   GetBinary(GetString(splitFloat[0]));
   GetBinary(splitFloat[1]);
}

/*Return String value of a float
 */
string aFixedPoint32::GetString(float flt)
{
   char chFlt[kMaxDigits];
   for(int i = 0; i< kMaxDigits; ++i)
      chFlt[i] = '0';
   sprintf(chFlt,"%f",flt);
   return string(chFlt);
}

/*Return two floats split by their decimal point
 */
void aFixedPoint32::Split(float flt, float* retVal)
{
   string strFloat = GetString(flt);
   int delPoint = strFloat.find(".", 0);
   string upper = strFloat.substr(0,delPoint);
   retVal[0] = atof(upper.c_str());
   retVal[1] = flt-retVal[0];
}

/* Converts the passed in unsigned int and creates
 * the binary data and stores it in fInt 
 */
void aFixedPoint32::IntToBin(unsigned int num)
{
   int n = num;
   int i = 0;
   for (;n!=0;n=n>>1)
   {
      ++i;
   }
   int no_bits = i;
   for (int j=no_bits-1; j>=0; --j)
   {  
      fInt[j] = (num >> j) & 01;
   }
}

/* This algorithm finds the binary sequence of a decimal 
 * sequence based on the Repeated Multiplication 
 * algorithm. It stores the result in fDec[] (a bool array).
 * see http://www.mathpath.org/concepts/Num/frac.htm 
 */
void aFixedPoint32::GetBinary(float flt)
{
   float ci;
   float splitFloat[2];
   int count = 0;
   float q = flt;
   do
   {
      ci = 2 * q; /*two is the base (binary) */
      Split(ci, splitFloat);
      /* [0] is the binary result of the split foat so we
       * store it in the class variable*/
      fDec[count] = splitFloat[0];  
      q = splitFloat[1];  /* [1] is the decimal part of the float */
      ++count;
   }while (q != 0); 
}

/* Get's the Binary information from a string by 
 * first converting it to an int, and then calls IntToBin
 * to store the binary information in the fInt array.
 */
void aFixedPoint32::GetBinary(string str)
{
   int result;
   if (StringToInt(str, result))
   {
      IntToBin(result);
   }
   else
   {
      cerr << "Number conversion failed!" << endl;
   }
}

/* Converts a string s to an int i using the sstream library.
 * If the conversion is successful it returns true
 * otherwise, false. 
 */
bool aFixedPoint32::StringToInt(const string& s, int& i)
{
   istringstream myStream(s);
   if (myStream>>i)
   {   
      return true;
   }
   else
   {
     return false;
   }
}

/* Remove the two binary arrays 
 */
aFixedPoint32::~aFixedPoint32()
{
   delete[] fInt;
   delete[] fDec;
}

/* Public method to return the Fixed point encoded object in a
 * string format
 *     signbit 16 int bits          15 decimal bits
 * EG. "<<0>><<0000000000000001>>.<<100000000000000>>" = 1.1 float
 */
string aFixedPoint32::ToString() 
{
   stringstream retVal;
   retVal << "<<" << fNegative << ">><<"; /*First bit is the sign bit */

   for(int i = kIntSize-1; i >= 0; --i) /*next kIntSize (16) bits are ints*/
   {
      retVal << fInt[i];
   }
   retVal << ">>.<<";
   for(int i = 0; i < kDecSize; ++i)
   {
      retVal << fDec[i];
   }
   retVal << ">>";
   return retVal.str();
}

/* Returns the floating point representation of the fixed point 
 * encoded object by adding up the values in base 2 (binary format)
*/
float aFixedPoint32::ToFloat()
{
   float flt = 0.0;
   //add up the integer bits
   for (int i = 0; i < kIntSize; ++i)
   {
      flt += pow((double)2,i) * fInt[i];
   }
   //add up the decimal bits
   for (int i = 1; i < kDecSize; ++i)
   {
      flt += (1 /(pow((double)2,i))) * fDec[i-1];
   }
   if (fNegative == 1)
   {
     flt *= (-1 * fNegative);
   }
   return flt;
}

