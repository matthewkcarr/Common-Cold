// Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr
// Purpose: Tests the FixedPoint class files to 
// ensure they work as specified.

#include <string>

#include "FixedPoint32.h"

/* This version of test will check the values of
 * FPE objects created with floats and ensure that
 * the FPE is correctly representing the value
 */
bool test(float floatNum, string rawStr)
{
   aFixedPoint32 fp(floatNum);
   string str = fp.ToString();
   if(floatNum == fp.ToFloat() && str.compare(rawStr) == 0)
   {
      cout << "Test passed for floating point number " 
           << floatNum << endl;
      return true;
   }
   else
   {
      cout << "DEBUG INFO: Test failed for floating point number " 
           << floatNum << endl;
      cout << "DEBUG INFO: float is "<< fp.ToFloat() 
           << " and string is "      << str << endl;
      return false;
   }
}

/* This version of test will check the values of
 * FPE objects created with unsigned int's and ensure that
 * the FPE is correctly representing the value
 */
bool test(unsigned int packedNum, string rawStr)
{
   aFixedPoint32 fp(packedNum);
   string str = fp.ToString();
   if(str.compare(rawStr) == 0 )
   {
      printf("Test passed for packed number %08x ... Float value is %f\n", 
             packedNum, fp.ToFloat());
      return true;
   }
   else
   {
      printf("DEBUG INFO: Test failed for packed number %08x\n", packedNum);
      printf("DEBUG INFO: String is %s\n", str.c_str()); 
      return false;
   }
}

/* The main function will run a series of tests to ensure that the
 * FixedPoint32 object is working correctly
 */
int main()
{
   //First Test for a simple float's
   test( float (1.0),      "<<0>><<0000000000000001>>.<<000000000000000>>");
   test( float(-1.0),      "<<1>><<0000000000000001>>.<<000000000000000>>");
   test( float (2.0),      "<<0>><<0000000000000010>>.<<000000000000000>>");
   test( float(-2.5),      "<<1>><<0000000000000010>>.<<100000000000000>>");
   test( float (65535.0),  "<<0>><<1111111111111111>>.<<000000000000000>>");

   cout << "Note that the next test number is -65535.99 and is converted to" 
        << "a string and compared to <<1>><<1111111111111111>>.<<111111010000000>>" 
        << "- but is converted to -65536.00 but still passes the" 
        << " binary ToString and ToFloat test." << endl;
   test( float (-65535.99),"<<1>><<1111111111111111>>.<<111111010000000>>");
   
   //going past this point in decimals leads to rounding and funky behavior
   //boundary/limit testing - note that on some systems 
   //that going past .995 or other numbers will add +1 to the 
   //integer section - so our real final boundary might be 65536 rather 
   //than 65535.999969 -or 65535.0000305... etc as it really shouldbe
   //in this case it would be safer to use packed int's
   test(float (65537.0), "this should fail in error");
   test(float (-65537.0),"this should fail in error");

   //Next test for packed unsigned int's
   unsigned int uInt = 0x00008000;
   test(uInt, "<<0>><<0000000000000001>>.<<000000000000000>>");
   uInt = 0x80008000;
   test(uInt, "<<1>><<0000000000000001>>.<<000000000000000>>");
   uInt = 0x00010000;
   test(uInt, "<<0>><<0000000000000010>>.<<000000000000000>>");
   uInt = 0x80014000;
   test(uInt, "<<1>><<0000000000000010>>.<<100000000000000>>");
   uInt = 0x7FFFFFFF;
   test(uInt, "<<0>><<1111111111111111>>.<<111111111111111>>");
   uInt = 0xFFFFFFFF;
   test(uInt, "<<1>><<1111111111111111>>.<<111111111111111>>");
}
