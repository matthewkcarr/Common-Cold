/ Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr

Compilation and Execution:
From the command line run:
./make
./testFixedPoint

Purpose: This program seeks to avoid the implementation differences of
floating type values between various systems by storing its own data structure
of 32 bits. Thus the AfixedPoint32 object will always give you 32 bits of data
no matter what system you are running it on.  

Testing:
This program has been tested for and will compile on g++ (GCC) 3.4.5 on Linux
Kernel 2.6.16.16 and g++ (GCC) 3.3.3 on Linux Kernel 2.6.5-1.358

List of Files and Description:

FixedPointDriver.cpp
-Tests the following files to ensure they work as specified.

FixedPoint32.h
-Header file for the 32 bit Fixed Point Encoding object.  Fixed Point objects
have 32 bits, the first bit is the sign bit, the next 16 bits represent the
integer portion of the number, the following 15 bits represent the decimal
part of the number.

FixedPoint32.cpp
-Implements the Fixed point Encoding object. It's main features include the
ability to make a FPE object by passing it a common float, or unsigned int
(packed number) and be able to convert it to a string representation of its
binary value or be able to convert it back to a float. 
The Largest possible number that can fit into a FPE object is around 65535.999969,
the least is -65535.999969.

Makefile
-Compiles the program by running "make" at the prompt.  The path settings used in the Makefile are relative to the makefile's current directory.  See http://www.mathpath.org/concepts/Num/frac.htm and the section on Repeated Multiplication Algorithm for deriving a binary representation of a floating point base 10 number. It is implemented in AfixedPoint32::GetBinary(float).

