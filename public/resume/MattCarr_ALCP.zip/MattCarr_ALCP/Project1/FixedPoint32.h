// Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr
// Purpose: The header file for the FixedPoint32 object is 
// contained here. Neccessary include files and public and 
// private method definitions are defined here. 
// See AlDocs/Readme.Txt for more info on the FP object.

#ifndef h_FixedPoint32
#define h_FixedPoint32
#define qDebug /*don't exit if some tests fail*/

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

class aFixedPoint32
{
   /* Largest possible number to fit here is around 65535.999939, 
    * least is -65535.999939 - largest character size is set to 40
    * characters including sign and period to give plenty of room*/
      bool* fDec;      /*binary array for decimal digits*/
      bool* fInt;      /*binary array for integer digits*/
      bool fNegative;  /*The sign bit +1 is negative 0 is positive*/

   public:
      //construction and destruction
      /* Passing an unsigned int (eg. 0x8000400)
       * will create a FPE like 
       * <<1>><<0000000000000001>><<000000000000000>>
       */
      aFixedPoint32(unsigned int);
      /* Passing a float (eg. -1.0)
       * will create a FPE like 
       * <<1>><<0000000000000001>><<000000000000000>>
       */
      aFixedPoint32(float);
      ~aFixedPoint32();	
      /* ToFloat will get the fixed point encoded object 
       * back in float format
       */
      float ToFloat();
      /* ToString will return the Fixed point encoded 
       * object in a string format - For example
       *  <<signbit>><<16 int bits>>.<<15 decimal bits>>
       * "<<0>><<0000000000000001>>.<<100000000000000>>" = 1.1 float
      */
      string ToString();

   private:
      /* CheckBounds makes sure that when the 
       * constructor is called that the value 
       * is not larger than the object can store
       */
      void CheckBounds(float);
      /* GetBinary converts the float or string value passed in by the
       *constructor to a BINARY array with the sign bit, 
       *16 int bits, and 15 decimal bits
      */
      void GetBinary(float);
      void GetBinary(string);
      //Get a string from the float value
      string GetString(float);
      //set all of the binary array's to an initial value of zero
      void Initialize();
      /* IntToBin converts the packed number (unsigned int) 
       *to binary and store it in the array
      */
      void IntToBin(unsigned int);
      /* Split splits a float by its int and decimal values
       * and store it in the reference
       * eg. Split(1.2, store)  results in store[0] = 1 and store[1] = .2
       */
      void Split(float, float*);
      //Converts a string value to an integer value
      bool StringToInt(const string&, int&);
};
#endif /* h_FixedPoint32 */
