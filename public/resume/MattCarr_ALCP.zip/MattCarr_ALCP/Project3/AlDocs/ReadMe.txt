/ Copyright (c) 2006 Art & Logic, Inc. All Rights Reserved.
// $ Id: $
// Author: Matthew Carr

Compilation and Execution:
From the command line run
./make
./debug

Purpose: 
This program tests whether or not the Convert method will in fact
change the buffer string to "Arts&Logic".

Testing:
This program has been tested for and will compile on g++ (GCC) 3.4.5 on Linux
Kernel 2.6.16.16 and g++ (GCC) 3.3.3 on Linux Kernel 2.6.5-1.358

List of Files and Description:

Debugging.cpp
-The main and convert methods are here.

Makefile
-Compiles the program by running "make" at the prompt.  The path settings used in the Makefile are relative to the makefile's current directory. 
