/****************************************************************************
** Form implementation generated from reading ui file 'instructorform.ui'
**
** Created: Mon Feb 21 01:38:15 2005
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.3   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "instructorform.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "../instructorform.ui.h"
/*
 *  Constructs a instructorForm as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
instructorForm::instructorForm( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "instructorForm" );
    instructorFormLayout = new QVBoxLayout( this, 11, 6, "instructorFormLayout"); 

    sendFeedtoGroup = new QGroupBox( this, "sendFeedtoGroup" );
    sendFeedtoGroup->setColumnLayout(0, Qt::Vertical );
    sendFeedtoGroup->layout()->setSpacing( 6 );
    sendFeedtoGroup->layout()->setMargin( 11 );
    sendFeedtoGroupLayout = new QHBoxLayout( sendFeedtoGroup->layout() );
    sendFeedtoGroupLayout->setAlignment( Qt::AlignTop );

    layout17 = new QVBoxLayout( 0, 0, 6, "layout17"); 

    allStudentCompsCheckBox = new QCheckBox( sendFeedtoGroup, "allStudentCompsCheckBox" );
    layout17->addWidget( allStudentCompsCheckBox );

    projector1CheckBox = new QCheckBox( sendFeedtoGroup, "projector1CheckBox" );
    layout17->addWidget( projector1CheckBox );
    sendFeedtoGroupLayout->addLayout( layout17 );

    layout19 = new QVBoxLayout( 0, 0, 6, "layout19"); 

    projector2CheckBox = new QCheckBox( sendFeedtoGroup, "projector2CheckBox" );
    layout19->addWidget( projector2CheckBox );

    projector3CheckBox = new QCheckBox( sendFeedtoGroup, "projector3CheckBox" );
    layout19->addWidget( projector3CheckBox );
    sendFeedtoGroupLayout->addLayout( layout19 );
    instructorFormLayout->addWidget( sendFeedtoGroup );

    layout20 = new QHBoxLayout( 0, 0, 6, "layout20"); 

    closePushButton = new QPushButton( this, "closePushButton" );
    layout20->addWidget( closePushButton );
    spacer2 = new QSpacerItem( 141, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout20->addItem( spacer2 );

    applyPushButton = new QPushButton( this, "applyPushButton" );
    layout20->addWidget( applyPushButton );
    instructorFormLayout->addLayout( layout20 );
    languageChange();
    resize( QSize(340, 148).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( applyPushButton, SIGNAL( clicked() ), this, SLOT( applyButtonClicked() ) );
    connect( closePushButton, SIGNAL( clicked() ), this, SLOT( closeButtonClicked() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
instructorForm::~instructorForm()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void instructorForm::languageChange()
{
    setCaption( tr( "Instructor Computer" ) );
    sendFeedtoGroup->setTitle( tr( "Send Display feed from 'Ying' to:" ) );
    allStudentCompsCheckBox->setText( tr( "All Student Computers" ) );
    projector1CheckBox->setText( tr( "(P1) Projector 1" ) );
    projector2CheckBox->setText( tr( "(P2) Projector 2" ) );
    projector3CheckBox->setText( tr( "(P3) Projector 3" ) );
    closePushButton->setText( tr( "&Close" ) );
    closePushButton->setAccel( QKeySequence( tr( "Alt+C" ) ) );
    applyPushButton->setText( tr( "&Apply" ) );
    applyPushButton->setAccel( QKeySequence( tr( "Alt+A" ) ) );
}

