/****************************************************************************
** Form implementation generated from reading ui file 'aboutform.ui'
**
** Created: Mon Feb 21 04:21:39 2005
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.3   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "aboutform.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

/*
 *  Constructs a aboutForm as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
aboutForm::aboutForm( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "aboutForm" );

    infoLabel = new QLabel( this, "infoLabel" );
    infoLabel->setGeometry( QRect( 82, 12, 319, 17 ) );

    textLabel2 = new QLabel( this, "textLabel2" );
    textLabel2->setGeometry( QRect( 82, 35, 319, 16 ) );

    okpushbutton = new QPushButton( this, "okpushbutton" );
    okpushbutton->setGeometry( QRect( 137, 59, 78, 38 ) );
    okpushbutton->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, okpushbutton->sizePolicy().hasHeightForWidth() ) );
    okpushbutton->setIconSet( QIconSet( QPixmap::fromMimeSource( "button_ok.png" ) ) );
    languageChange();
    resize( QSize(343, 109).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( okpushbutton, SIGNAL( clicked() ), this, SLOT( close() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
aboutForm::~aboutForm()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void aboutForm::languageChange()
{
    setCaption( tr( "About" ) );
    setIconText( QString::null );
    infoLabel->setText( tr( "Created By Matthew Carr 2005" ) );
    textLabel2->setText( tr( "on Trolltech's QT Designer" ) );
    okpushbutton->setText( tr( "&Ok" ) );
    okpushbutton->setAccel( QKeySequence( tr( "Alt+O" ) ) );
}

