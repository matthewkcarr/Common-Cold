/****************************************************************************
** Form interface generated from reading ui file 'rowdialogue.ui'
**
** Created: Mon Feb 21 04:09:02 2005
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.3   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef ROWDIALOGUE_H
#define ROWDIALOGUE_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QWidgetStack;
class QWidget;
class QGroupBox;
class QCheckBox;
class QRadioButton;
class QPushButton;
class QIconView;
class QIconViewItem;

class rowDialogue : public QDialog
{
    Q_OBJECT

public:
    rowDialogue( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~rowDialogue();

    QLabel* selectLabel;
    QWidgetStack* stCompOptionswidgetStack;
    QWidget* compOptionsPage1;
    QGroupBox* groupBox5;
    QCheckBox* takeKeys;
    QCheckBox* takeMouse;
    QGroupBox* projectorBoxContainer;
    QGroupBox* projectorGroupBoxContainer;
    QCheckBox* projector1CheckBox;
    QCheckBox* projector2CheckBox;
    QCheckBox* allStudentsCheckBox;
    QCheckBox* yingCheckBox;
    QCheckBox* yangCheckBox;
    QCheckBox* projector3CheckBox;
    QRadioButton* chooseDeviceRadioButton;
    QRadioButton* noneRadioButton;
    QPushButton* acceptPushButton;
    QIconView* studentCompIconView;
    QPushButton* closePushButton;

    QIconViewItem * icon1;
    QString * computerNames;
    QIconViewItem * icon2;
    QIconViewItem * icon3;
    QIconViewItem * icon4;

public slots:
    virtual void settheNames( QString * comps, QString rownum );
    virtual void noneRadioStateClicked();
    virtual void devicechooseClicked();

protected:

protected slots:
    virtual void languageChange();

private:
    void init();

};

#endif // ROWDIALOGUE_H
