/*@author Matthew Carr 
@date 2/14/04
*/
/*#ifdef __cplusplus
extern "C" {
#endif 
*/
#include <qwidget.h>
#include <qpushbutton.h>
#include <qthread.h>


class QLightSwitch : public QPushButton 
{
private:
	int state;
	bool tristate;
public:
	QPixmap down;
	QPixmap up;
	QPixmap middle;
	QLightSwitch( QWidget * , const char* , bool );
	~QLightSwitch(){}
	void doClick();
public slots:
	void animateClick();
	void toggle();
};
/*#ifdef __cplusplus
}
#endif
*/
