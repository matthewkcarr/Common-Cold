/****************************************************************************
** Form implementation generated from reading ui file 'rowdialogue.ui'
**
** Created: Mon Feb 21 01:38:05 2005
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.3   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "rowdialogue.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qwidgetstack.h>
#include <qwidget.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qradiobutton.h>
#include <qpushbutton.h>
#include <qiconview.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "../rowdialogue.ui.h"
/*
 *  Constructs a rowDialogue as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
rowDialogue::rowDialogue( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "rowDialogue" );
    setMinimumSize( QSize( 380, 380 ) );

    selectLabel = new QLabel( this, "selectLabel" );
    selectLabel->setGeometry( QRect( 10, 10, 185, 20 ) );

    stCompOptionswidgetStack = new QWidgetStack( this, "stCompOptionswidgetStack" );
    stCompOptionswidgetStack->setGeometry( QRect( 10, 110, 375, 236 ) );

    compOptionsPage1 = new QWidget( stCompOptionswidgetStack, "compOptionsPage1" );

    groupBox5 = new QGroupBox( compOptionsPage1, "groupBox5" );
    groupBox5->setGeometry( QRect( 11, 169, 353, 56 ) );

    takeKeys = new QCheckBox( groupBox5, "takeKeys" );
    takeKeys->setGeometry( QRect( 180, 23, 161, 21 ) );

    takeMouse = new QCheckBox( groupBox5, "takeMouse" );
    takeMouse->setGeometry( QRect( 12, 23, 162, 21 ) );

    projectorBoxContainer = new QGroupBox( compOptionsPage1, "projectorBoxContainer" );
    projectorBoxContainer->setGeometry( QRect( 11, 11, 353, 152 ) );

    projectorGroupBoxContainer = new QGroupBox( projectorBoxContainer, "projectorGroupBoxContainer" );
    projectorGroupBoxContainer->setEnabled( FALSE );
    projectorGroupBoxContainer->setGeometry( QRect( 100, 20, 241, 110 ) );

    projector1CheckBox = new QCheckBox( projectorGroupBoxContainer, "projector1CheckBox" );
    projector1CheckBox->setEnabled( FALSE );
    projector1CheckBox->setGeometry( QRect( 12, 23, 91, 21 ) );

    projector2CheckBox = new QCheckBox( projectorGroupBoxContainer, "projector2CheckBox" );
    projector2CheckBox->setEnabled( FALSE );
    projector2CheckBox->setGeometry( QRect( 12, 50, 91, 21 ) );

    allStudentsCheckBox = new QCheckBox( projectorGroupBoxContainer, "allStudentsCheckBox" );
    allStudentsCheckBox->setGeometry( QRect( 111, 23, 118, 21 ) );

    yingCheckBox = new QCheckBox( projectorGroupBoxContainer, "yingCheckBox" );
    yingCheckBox->setEnabled( FALSE );
    yingCheckBox->setGeometry( QRect( 111, 50, 118, 21 ) );

    yangCheckBox = new QCheckBox( projectorGroupBoxContainer, "yangCheckBox" );
    yangCheckBox->setEnabled( FALSE );
    yangCheckBox->setGeometry( QRect( 111, 77, 118, 21 ) );

    projector3CheckBox = new QCheckBox( projectorGroupBoxContainer, "projector3CheckBox" );
    projector3CheckBox->setEnabled( FALSE );
    projector3CheckBox->setGeometry( QRect( 12, 77, 91, 21 ) );

    chooseDeviceRadioButton = new QRadioButton( projectorBoxContainer, "chooseDeviceRadioButton" );
    chooseDeviceRadioButton->setEnabled( TRUE );
    chooseDeviceRadioButton->setGeometry( QRect( 11, 53, 81, 21 ) );
    chooseDeviceRadioButton->setChecked( FALSE );

    noneRadioButton = new QRadioButton( projectorBoxContainer, "noneRadioButton" );
    noneRadioButton->setEnabled( TRUE );
    noneRadioButton->setGeometry( QRect( 11, 26, 81, 21 ) );
    noneRadioButton->setChecked( TRUE );
    stCompOptionswidgetStack->addWidget( compOptionsPage1, 0 );

    acceptPushButton = new QPushButton( this, "acceptPushButton" );
    acceptPushButton->setGeometry( QRect( 303, 351, 80, 32 ) );

    studentCompIconView = new QIconView( this, "studentCompIconView" );
    studentCompIconView->setGeometry( QRect( 10, 40, 370, 68 ) );
    studentCompIconView->setAcceptDrops( FALSE );
    studentCompIconView->setVScrollBarMode( QIconView::AlwaysOff );
    studentCompIconView->setHScrollBarMode( QIconView::AlwaysOff );
    studentCompIconView->setDragAutoScroll( FALSE );
    studentCompIconView->setItemTextPos( QIconView::Bottom );
    studentCompIconView->setAutoArrange( TRUE );
    studentCompIconView->setItemsMovable( FALSE );

    closePushButton = new QPushButton( this, "closePushButton" );
    closePushButton->setGeometry( QRect( 181, 351, 80, 32 ) );
    languageChange();
    resize( QSize(380, 380).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( chooseDeviceRadioButton, SIGNAL( clicked() ), this, SLOT( devicechooseClicked() ) );
    connect( noneRadioButton, SIGNAL( clicked() ), this, SLOT( noneRadioStateClicked() ) );
    connect( acceptPushButton, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( closePushButton, SIGNAL( clicked() ), this, SLOT( close() ) );
    // tab order
    setTabOrder( studentCompIconView, noneRadioButton );
    setTabOrder( noneRadioButton, chooseDeviceRadioButton );
    setTabOrder( chooseDeviceRadioButton, projector1CheckBox );
    setTabOrder( projector1CheckBox, projector2CheckBox );
    setTabOrder( projector2CheckBox, projector3CheckBox );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
rowDialogue::~rowDialogue()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void rowDialogue::languageChange()
{
    setCaption( tr( "Student Computer Options" ) );
    selectLabel->setText( tr( "Select a Computer from row \" \":" ) );
    groupBox5->setTitle( tr( "Take Control of:" ) );
    takeKeys->setText( tr( "Keyboard" ) );
    takeMouse->setText( tr( "Mouse" ) );
    projectorBoxContainer->setTitle( tr( "Send Display Feed to: " ) );
    projectorGroupBoxContainer->setTitle( tr( "Choose Devices:" ) );
    projector1CheckBox->setText( tr( "Projector 1" ) );
    projector2CheckBox->setText( tr( "Projector 2" ) );
    allStudentsCheckBox->setText( tr( "All Students" ) );
    yingCheckBox->setText( tr( "Computer Ying" ) );
    yangCheckBox->setText( tr( "Computer Yang" ) );
    projector3CheckBox->setText( tr( "Projector 3" ) );
    chooseDeviceRadioButton->setText( tr( "A Device" ) );
    noneRadioButton->setText( tr( "None" ) );
    acceptPushButton->setText( tr( "Apply" ) );
    studentCompIconView->clear();
    (void) new QIconViewItem( studentCompIconView, tr( "LeftMostComp" ) );
    (void) new QIconViewItem( studentCompIconView, tr( "Left2Comp" ) );
    (void) new QIconViewItem( studentCompIconView, tr( "Right1Comp" ) );
    (void) new QIconViewItem( studentCompIconView, tr( "RightMostComp" ) );
    closePushButton->setText( tr( "Close" ) );
}

