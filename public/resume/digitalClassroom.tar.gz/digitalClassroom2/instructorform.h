/****************************************************************************
** Form interface generated from reading ui file 'instructorform.ui'
**
** Created: Mon Feb 21 01:35:12 2005
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.3   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef INSTRUCTORFORM_H
#define INSTRUCTORFORM_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QCheckBox;
class QPushButton;

class instructorForm : public QDialog
{
    Q_OBJECT

public:
    instructorForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~instructorForm();

    QGroupBox* sendFeedtoGroup;
    QCheckBox* allStudentCompsCheckBox;
    QCheckBox* projector1CheckBox;
    QCheckBox* projector2CheckBox;
    QCheckBox* projector3CheckBox;
    QPushButton* closePushButton;
    QPushButton* applyPushButton;

    virtual void dudeFunction(QString str);

public slots:
    virtual void applyButtonClicked();
    virtual void closeButtonClicked();

protected:
    QVBoxLayout* instructorFormLayout;
    QHBoxLayout* sendFeedtoGroupLayout;
    QVBoxLayout* layout17;
    QVBoxLayout* layout19;
    QHBoxLayout* layout20;
    QSpacerItem* spacer2;

protected slots:
    virtual void languageChange();

};

#endif // INSTRUCTORFORM_H
