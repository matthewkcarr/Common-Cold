/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you want to add, delete, or rename functions or slots, use
** Qt Designer to update this file, preserving your code.
**
** You should not define a constructor or destructor in this file.
** Instead, write your code in functions called init() and destroy().
** These will automatically be called by the form's constructor and
** destructor.
*****************************************************************************/


void rowDialogue::init()
{

}
void rowDialogue::settheNames( QString * comps, QString rownum )
{
    computerNames = new QString[4];
    computerNames[0] = comps[0];
    computerNames[1] = comps[1];
    computerNames[2] = comps[2];
    computerNames[3] = comps[3];
 studentCompIconView->clear();
 icon1 = new QIconViewItem( studentCompIconView, tr( computerNames[0]  ), QPixmap::fromMimeSource( "monitor.xpm" ) );
 icon2 = new QIconViewItem( studentCompIconView, tr( computerNames[1]  ), QPixmap::fromMimeSource( "monitor.xpm" ) );
 icon3 = new QIconViewItem( studentCompIconView, tr( computerNames[2] ), QPixmap::fromMimeSource( "monitor.xpm" ) );
 icon4 = new QIconViewItem( studentCompIconView, tr(computerNames[3]) , QPixmap::fromMimeSource( "monitor.xpm" ) );
 studentCompIconView->insertItem( icon1);
 studentCompIconView->insertItem( icon2);
 studentCompIconView->insertItem( icon3);
 studentCompIconView->insertItem( icon4);
 studentCompIconView->ensureItemVisible(icon1);
 studentCompIconView->ensureItemVisible(icon2);
 studentCompIconView->ensureItemVisible(icon3);
selectLabel->setText( tr( "Select a Computer from row \"" + rownum + "\":" ));
}



void rowDialogue::noneRadioStateClicked()
{
    projectorGroupBoxContainer->setEnabled(FALSE);
    projector1CheckBox->setEnabled(FALSE);
    projector2CheckBox->setEnabled(FALSE);
    allStudentsCheckBox->setEnabled(FALSE);
    projector3CheckBox->setEnabled(FALSE);
    yingCheckBox->setEnabled(FALSE);
    yangCheckBox->setEnabled(FALSE);
    noneRadioButton->setChecked(TRUE);
    chooseDeviceRadioButton->setChecked(FALSE);
    update();
}


void rowDialogue::devicechooseClicked()
{
    projectorGroupBoxContainer->setEnabled(TRUE);
    projector1CheckBox->setEnabled(TRUE);
    projector2CheckBox->setEnabled(TRUE);
    allStudentsCheckBox->setEnabled(TRUE);
    projector3CheckBox->setEnabled(TRUE);
    yingCheckBox->setEnabled(TRUE);
    yangCheckBox->setEnabled(TRUE);
    noneRadioButton->setChecked(FALSE);
    chooseDeviceRadioButton->setChecked(TRUE);
    update();
}
