/****************************************************************************
** rowDialogue meta object code from reading C++ file 'rowdialogue.h'
**
** Created: Mon Feb 21 05:17:34 2005
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.3   edited Aug 5 16:40 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../rowdialogue.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *rowDialogue::className() const
{
    return "rowDialogue";
}

QMetaObject *rowDialogue::metaObj = 0;
static QMetaObjectCleanUp cleanUp_rowDialogue( "rowDialogue", &rowDialogue::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString rowDialogue::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "rowDialogue", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString rowDialogue::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "rowDialogue", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* rowDialogue::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "comps", &static_QUType_varptr, "\x03", QUParameter::In },
	{ "rownum", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"settheNames", 2, param_slot_0 };
    static const QUMethod slot_1 = {"noneRadioStateClicked", 0, 0 };
    static const QUMethod slot_2 = {"devicechooseClicked", 0, 0 };
    static const QUMethod slot_3 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "settheNames(QString*,QString)", &slot_0, QMetaData::Public },
	{ "noneRadioStateClicked()", &slot_1, QMetaData::Public },
	{ "devicechooseClicked()", &slot_2, QMetaData::Public },
	{ "languageChange()", &slot_3, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"rowDialogue", parentObject,
	slot_tbl, 4,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_rowDialogue.setMetaObject( metaObj );
    return metaObj;
}

void* rowDialogue::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "rowDialogue" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool rowDialogue::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: settheNames((QString*)static_QUType_varptr.get(_o+1),(QString)static_QUType_QString.get(_o+2)); break;
    case 1: noneRadioStateClicked(); break;
    case 2: devicechooseClicked(); break;
    case 3: languageChange(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool rowDialogue::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool rowDialogue::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool rowDialogue::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
