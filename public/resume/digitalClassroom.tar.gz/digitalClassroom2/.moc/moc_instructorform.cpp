/****************************************************************************
** instructorForm meta object code from reading C++ file 'instructorform.h'
**
** Created: Mon Feb 21 05:17:40 2005
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.3   edited Aug 5 16:40 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../instructorform.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *instructorForm::className() const
{
    return "instructorForm";
}

QMetaObject *instructorForm::metaObj = 0;
static QMetaObjectCleanUp cleanUp_instructorForm( "instructorForm", &instructorForm::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString instructorForm::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "instructorForm", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString instructorForm::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "instructorForm", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* instructorForm::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"applyButtonClicked", 0, 0 };
    static const QUMethod slot_1 = {"closeButtonClicked", 0, 0 };
    static const QUMethod slot_2 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "applyButtonClicked()", &slot_0, QMetaData::Public },
	{ "closeButtonClicked()", &slot_1, QMetaData::Public },
	{ "languageChange()", &slot_2, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"instructorForm", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_instructorForm.setMetaObject( metaObj );
    return metaObj;
}

void* instructorForm::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "instructorForm" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool instructorForm::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: applyButtonClicked(); break;
    case 1: closeButtonClicked(); break;
    case 2: languageChange(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool instructorForm::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool instructorForm::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool instructorForm::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
