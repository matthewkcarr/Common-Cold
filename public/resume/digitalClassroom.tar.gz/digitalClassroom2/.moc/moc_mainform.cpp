/****************************************************************************
** MainForm meta object code from reading C++ file 'mainform.h'
**
** Created: Mon Feb 21 05:17:26 2005
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.3   edited Aug 5 16:40 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../mainform.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *MainForm::className() const
{
    return "MainForm";
}

QMetaObject *MainForm::metaObj = 0;
static QMetaObjectCleanUp cleanUp_MainForm( "MainForm", &MainForm::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString MainForm::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "MainForm", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString MainForm::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "MainForm", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* MainForm::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QMainWindow::staticMetaObject();
    static const QUMethod slot_0 = {"fileOpen", 0, 0 };
    static const QUMethod slot_1 = {"fileSave", 0, 0 };
    static const QUMethod slot_2 = {"fileSaveAs", 0, 0 };
    static const QUMethod slot_3 = {"filePrint", 0, 0 };
    static const QUMethod slot_4 = {"fileExit", 0, 0 };
    static const QUMethod slot_5 = {"editUndo", 0, 0 };
    static const QUMethod slot_6 = {"editRedo", 0, 0 };
    static const QUMethod slot_7 = {"editCut", 0, 0 };
    static const QUMethod slot_8 = {"editCopy", 0, 0 };
    static const QUMethod slot_9 = {"editPaste", 0, 0 };
    static const QUMethod slot_10 = {"editFind", 0, 0 };
    static const QUMethod slot_11 = {"helpIndex", 0, 0 };
    static const QUMethod slot_12 = {"helpContents", 0, 0 };
    static const QUMethod slot_13 = {"helpAbout", 0, 0 };
    static const QUMethod slot_14 = {"fourthRowClicked", 0, 0 };
    static const QUMethod slot_15 = {"fifthRowClicked", 0, 0 };
    static const QUMethod slot_16 = {"thirdRowClicked", 0, 0 };
    static const QUMethod slot_17 = {"secondRowClicked", 0, 0 };
    static const QUMethod slot_18 = {"firstRowClicked", 0, 0 };
    static const QUMethod slot_19 = {"backLightsClicked", 0, 0 };
    static const QUMethod slot_20 = {"studentLightsClicked", 0, 0 };
    static const QUParameter param_slot_21[] = {
	{ "value", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_21 = {"setValue", 1, param_slot_21 };
    static const QUMethod slot_22 = {"stageLightsOff", 0, 0 };
    static const QUMethod slot_23 = {"stageLights10", 0, 0 };
    static const QUMethod slot_24 = {"stageLights20", 0, 0 };
    static const QUMethod slot_25 = {"stageLights30", 0, 0 };
    static const QUMethod slot_26 = {"stageLights40", 0, 0 };
    static const QUMethod slot_27 = {"stageLights50", 0, 0 };
    static const QUMethod slot_28 = {"stageLights60", 0, 0 };
    static const QUMethod slot_29 = {"stageLights70", 0, 0 };
    static const QUMethod slot_30 = {"stageLights80", 0, 0 };
    static const QUMethod slot_31 = {"stageLights90", 0, 0 };
    static const QUMethod slot_32 = {"stageLightsMax", 0, 0 };
    static const QUMethod slot_33 = {"studentLightsMax", 0, 0 };
    static const QUMethod slot_34 = {"studentLightsMed", 0, 0 };
    static const QUMethod slot_35 = {"studentLightsOff", 0, 0 };
    static const QUMethod slot_36 = {"backLightsOn", 0, 0 };
    static const QUMethod slot_37 = {"backLightsOff", 0, 0 };
    static const QUMethod slot_38 = {"yangComputer", 0, 0 };
    static const QUMethod slot_39 = {"yingComputer", 0, 0 };
    static const QUMethod slot_40 = {"projector1Clicked", 0, 0 };
    static const QUMethod slot_41 = {"projector2Clicked", 0, 0 };
    static const QUMethod slot_42 = {"projector3Clicked", 0, 0 };
    static const QUMethod slot_43 = {"projector1On", 0, 0 };
    static const QUMethod slot_44 = {"projector1Off", 0, 0 };
    static const QUMethod slot_45 = {"projector2Off", 0, 0 };
    static const QUMethod slot_46 = {"projector2On", 0, 0 };
    static const QUMethod slot_47 = {"projector3On", 0, 0 };
    static const QUMethod slot_48 = {"projector3Off", 0, 0 };
    static const QUMethod slot_49 = {"stageLightsClicked", 0, 0 };
    static const QUMethod slot_50 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "fileOpen()", &slot_0, QMetaData::Public },
	{ "fileSave()", &slot_1, QMetaData::Public },
	{ "fileSaveAs()", &slot_2, QMetaData::Public },
	{ "filePrint()", &slot_3, QMetaData::Public },
	{ "fileExit()", &slot_4, QMetaData::Public },
	{ "editUndo()", &slot_5, QMetaData::Public },
	{ "editRedo()", &slot_6, QMetaData::Public },
	{ "editCut()", &slot_7, QMetaData::Public },
	{ "editCopy()", &slot_8, QMetaData::Public },
	{ "editPaste()", &slot_9, QMetaData::Public },
	{ "editFind()", &slot_10, QMetaData::Public },
	{ "helpIndex()", &slot_11, QMetaData::Public },
	{ "helpContents()", &slot_12, QMetaData::Public },
	{ "helpAbout()", &slot_13, QMetaData::Public },
	{ "fourthRowClicked()", &slot_14, QMetaData::Public },
	{ "fifthRowClicked()", &slot_15, QMetaData::Public },
	{ "thirdRowClicked()", &slot_16, QMetaData::Public },
	{ "secondRowClicked()", &slot_17, QMetaData::Public },
	{ "firstRowClicked()", &slot_18, QMetaData::Public },
	{ "backLightsClicked()", &slot_19, QMetaData::Public },
	{ "studentLightsClicked()", &slot_20, QMetaData::Public },
	{ "setValue(int)", &slot_21, QMetaData::Public },
	{ "stageLightsOff()", &slot_22, QMetaData::Public },
	{ "stageLights10()", &slot_23, QMetaData::Public },
	{ "stageLights20()", &slot_24, QMetaData::Public },
	{ "stageLights30()", &slot_25, QMetaData::Public },
	{ "stageLights40()", &slot_26, QMetaData::Public },
	{ "stageLights50()", &slot_27, QMetaData::Public },
	{ "stageLights60()", &slot_28, QMetaData::Public },
	{ "stageLights70()", &slot_29, QMetaData::Public },
	{ "stageLights80()", &slot_30, QMetaData::Public },
	{ "stageLights90()", &slot_31, QMetaData::Public },
	{ "stageLightsMax()", &slot_32, QMetaData::Public },
	{ "studentLightsMax()", &slot_33, QMetaData::Public },
	{ "studentLightsMed()", &slot_34, QMetaData::Public },
	{ "studentLightsOff()", &slot_35, QMetaData::Public },
	{ "backLightsOn()", &slot_36, QMetaData::Public },
	{ "backLightsOff()", &slot_37, QMetaData::Public },
	{ "yangComputer()", &slot_38, QMetaData::Public },
	{ "yingComputer()", &slot_39, QMetaData::Public },
	{ "projector1Clicked()", &slot_40, QMetaData::Public },
	{ "projector2Clicked()", &slot_41, QMetaData::Public },
	{ "projector3Clicked()", &slot_42, QMetaData::Public },
	{ "projector1On()", &slot_43, QMetaData::Public },
	{ "projector1Off()", &slot_44, QMetaData::Public },
	{ "projector2Off()", &slot_45, QMetaData::Public },
	{ "projector2On()", &slot_46, QMetaData::Public },
	{ "projector3On()", &slot_47, QMetaData::Public },
	{ "projector3Off()", &slot_48, QMetaData::Public },
	{ "stageLightsClicked()", &slot_49, QMetaData::Public },
	{ "languageChange()", &slot_50, QMetaData::Protected }
    };
    static const QUParameter param_signal_0[] = {
	{ "nameComp", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"instructorCompSelected", 1, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "instructorCompSelected(QString)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"MainForm", parentObject,
	slot_tbl, 51,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_MainForm.setMetaObject( metaObj );
    return metaObj;
}

void* MainForm::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "MainForm" ) )
	return this;
    return QMainWindow::qt_cast( clname );
}

// SIGNAL instructorCompSelected
void MainForm::instructorCompSelected( QString t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 0, t0 );
}

bool MainForm::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: fileOpen(); break;
    case 1: fileSave(); break;
    case 2: fileSaveAs(); break;
    case 3: filePrint(); break;
    case 4: fileExit(); break;
    case 5: editUndo(); break;
    case 6: editRedo(); break;
    case 7: editCut(); break;
    case 8: editCopy(); break;
    case 9: editPaste(); break;
    case 10: editFind(); break;
    case 11: helpIndex(); break;
    case 12: helpContents(); break;
    case 13: helpAbout(); break;
    case 14: fourthRowClicked(); break;
    case 15: fifthRowClicked(); break;
    case 16: thirdRowClicked(); break;
    case 17: secondRowClicked(); break;
    case 18: firstRowClicked(); break;
    case 19: backLightsClicked(); break;
    case 20: studentLightsClicked(); break;
    case 21: setValue((int)static_QUType_int.get(_o+1)); break;
    case 22: stageLightsOff(); break;
    case 23: stageLights10(); break;
    case 24: stageLights20(); break;
    case 25: stageLights30(); break;
    case 26: stageLights40(); break;
    case 27: stageLights50(); break;
    case 28: stageLights60(); break;
    case 29: stageLights70(); break;
    case 30: stageLights80(); break;
    case 31: stageLights90(); break;
    case 32: stageLightsMax(); break;
    case 33: studentLightsMax(); break;
    case 34: studentLightsMed(); break;
    case 35: studentLightsOff(); break;
    case 36: backLightsOn(); break;
    case 37: backLightsOff(); break;
    case 38: yangComputer(); break;
    case 39: yingComputer(); break;
    case 40: projector1Clicked(); break;
    case 41: projector2Clicked(); break;
    case 42: projector3Clicked(); break;
    case 43: projector1On(); break;
    case 44: projector1Off(); break;
    case 45: projector2Off(); break;
    case 46: projector2On(); break;
    case 47: projector3On(); break;
    case 48: projector3Off(); break;
    case 49: stageLightsClicked(); break;
    case 50: languageChange(); break;
    default:
	return QMainWindow::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool MainForm::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: instructorCompSelected((QString)static_QUType_QString.get(_o+1)); break;
    default:
	return QMainWindow::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool MainForm::qt_property( int id, int f, QVariant* v)
{
    return QMainWindow::qt_property( id, f, v);
}

bool MainForm::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
