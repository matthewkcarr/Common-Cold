/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you want to add, delete, or rename functions or slots, use
** Qt Designer to update this file, preserving your code.
**
** You should not define a constructor or destructor in this file.
** Instead, write your code in functions called init() and destroy().
** These will automatically be called by the form's constructor and
** destructor.
*****************************************************************************/
#include <iostream.h>
/*@author Matthew Carr 
@date 2/14/04
*/
/* XPM */

//QPixmap projectorOn;
//int tristate;
int backLightsState;
int studentLightsState;
int stageLightsState;
int p1State;
int p2State;
int p3State;

void MainForm::init()
{
    //allComps[5][4] = new QString[5][4];
    allComps[0][0] = "1-Alpha"; 
    allComps[0][1] = "2-Bravo";
    allComps[0][2] = "3-Charlie";
    allComps[0][3] = "4-Delta"; 
    allComps[1][0] = "5-Echo"; 
    allComps[1][1] = "6-Foxtrot";
    allComps[1][2] = "7- Golf";
    allComps[1][3] = "8-Hotel";
    allComps[2][0] = "9-India";
    allComps[2][1] = "10-Juliet";
    allComps[2][2] = "11-Kilo"; 
    allComps[2][3] = "12-Lima";
    allComps[3][0] = "13-Mike"; 
    allComps[3][1] = "14-November"; 
    allComps[3][2] = "15-Oscar";
    allComps[3][3] = "16-Papa"; 
    allComps[4][0] = "17-Quebec";
    allComps[4][1] = "18-Romeo"; 
    allComps[4][2] = "19-Sierra"; 
    allComps[4][3] = "20-Tango";
    projector1PushButton->setPixmap(image1);
    projector2PushButton->setPixmap(image1);
    projector3PushButton->setPixmap(image1);
 studentLightsPushButton->setFlat(true);
 backLightsPushButton->setFlat(true);
    backLightsState = 0;
    studentLightsState = 0;
    stageLightsState = 0;
	p3State = 0;
	p2State = 0;
	p1State = 0;
 studentLightsPushButton->setPixmap(down);
 backLightsPushButton->setPixmap(down);

}


void MainForm::fileOpen()
{

}


void MainForm::fileSave()
{

}


void MainForm::fileSaveAs()
{

}


void MainForm::filePrint()
{

}


void MainForm::fileExit()
{
	close();

}


void MainForm::editUndo()
{

}


void MainForm::editRedo()
{

}


void MainForm::editCut()
{

}


void MainForm::editCopy()
{

}


void MainForm::editPaste()
{

}


void MainForm::editFind()
{

}


void MainForm::helpIndex()
{

}


void MainForm::helpContents()
{

}


void MainForm::helpAbout()
{
    aboutForm * about = new aboutForm(this, "", TRUE, 0);
    about->exec();
}



void MainForm::fourthRowClicked()
{

    rowDialogue * compPopup = new rowDialogue(this, "", TRUE);
    compPopup->settheNames(allComps[3], "4");
    compPopup->exec();
}


void MainForm::fifthRowClicked()
{
    rowDialogue * compPopup = new rowDialogue(this, "", TRUE);
    compPopup->settheNames(allComps[4], "5");
    compPopup->exec();
}


void MainForm::thirdRowClicked()
{
    rowDialogue * compPopup = new rowDialogue(this, "", TRUE);
    compPopup->settheNames(allComps[2], "3");
    compPopup->exec();
}


void MainForm::secondRowClicked()
{

    rowDialogue * compPopup = new rowDialogue(this, "", TRUE);
    compPopup->settheNames(allComps[1], "2");
    compPopup->exec();
}


void MainForm::firstRowClicked()
{
    rowDialogue * compPopup = new rowDialogue(this, "", TRUE);
    compPopup->settheNames(allComps[0], "1");
    compPopup->exec();
}


void MainForm::backLightsClicked()
{
	doClick(false, &backLightsState, backLightsPushButton);
        switch( backLightsState)
        {
		case 0:
			brOff->setOn(TRUE);
			break;
		case 2:
			brOn->setOn(TRUE);
			break;
	}
        update();

}


void MainForm::studentLightsClicked()
{
         
	doClick(true, &studentLightsState, studentLightsPushButton);
        switch( studentLightsState)
        {
		case 0:
			slOff->setOn(TRUE);
			break;
		case 1:
			slMed->setOn(TRUE);
			break;
		case 2:
			slMax->setOn(TRUE);
			break;
	}
        update();

}



void MainForm::setValue(int value)
{
//       cout << "value of slider is " << value << endl;
	    stageLightsSlider->blockSignals( TRUE );
	    stageLightsSlider->setValue( value );
	    stageLightsSlider->blockSignals( FALSE );
	value = 100-(value+1);
	if( value == 100)
	{	stOn->setOn(TRUE);		}
	else if(value > 89)
	{       st90->setOn(TRUE);		}
	else if(value > 79 )
	{	st80->setOn(TRUE);		}
	else if(value > 69 )
	{	st70->setOn(TRUE);			}
	else if(value > 59)
	{	st60->setOn(TRUE);			}
	else if(value > 49 )
	{	st50->setOn(TRUE);			}
	else if(value > 39)
	{	st40->setOn(TRUE);			}
	else if(value > 29)
	{	st30->setOn(TRUE);			}
	else if(value > 19 )
	{	st20->setOn(TRUE);			}
	else if(value >= 1 )
	{	st10->setOn(TRUE);			}
	else
	        stOff->setOn(TRUE);		
	update();
}

void MainForm::stageLightsOff()
{

	stageLightsSlider->setValue(99);
}


void MainForm::stageLights10()
{

	stageLightsSlider->setValue(90);
}


void MainForm::stageLights20()
{
	stageLightsSlider->setValue(80);
}


void MainForm::stageLights30()
{

	stageLightsSlider->setValue(70);
}


void MainForm::stageLights40()
{

	stageLightsSlider->setValue(60);
}


void MainForm::stageLights50()
{

	stageLightsSlider->setValue(50);
}


void MainForm::stageLights60()
{

	stageLightsSlider->setValue(40);
}


void MainForm::stageLights70()
{

	stageLightsSlider->setValue(30);
}


void MainForm::stageLights80()
{

	stageLightsSlider->setValue(20);
}


void MainForm::stageLights90()
{

	stageLightsSlider->setValue(10);
}


void MainForm::stageLightsMax()
{

	stageLightsSlider->setValue(0);
}


void MainForm::studentLightsMax()
{
	studentLightsState = 1;
	doClick(true, &studentLightsState, studentLightsPushButton);
        update();
}


void MainForm::studentLightsMed()
{

	studentLightsState = 0;
	doClick(true, &studentLightsState, studentLightsPushButton);
        update();
}


void MainForm::studentLightsOff()
{

	studentLightsState = 2;
	doClick(true, &studentLightsState, studentLightsPushButton);
        update();
}


void MainForm::backLightsOn()
{
        backLightsState = 0;
	doClick(false, &backLightsState, backLightsPushButton);
        update();
}


void MainForm::backLightsOff()
{

        backLightsState = 2;
	doClick(false, &backLightsState, backLightsPushButton);
	update();
}


void MainForm::yangComputer()
{
	instructorForm * IF = new instructorForm(this, "", TRUE);
        IF->dudeFunction("Yang");
	IF->exec();
}


void MainForm::yingComputer()
{

	instructorForm * IF = new instructorForm(this, "", TRUE);
        IF->dudeFunction("Ying");
	IF->exec();
}


void MainForm::projector1Clicked()
{
   if( p1State == 0)
   {	   projector1PushButton->setPixmap( image2); 
           p1State = 1;
           p1On->setOn(TRUE);
   }
   else
   {	   projector1PushButton->setPixmap( image1); 
           p1State = 0;
           p1Off->setOn(TRUE);
   }
   update();
}


void MainForm::projector2Clicked()
{

   if( p2State == 0)
   {	   projector2PushButton->setPixmap( image2); 
           p2State = 1;
           p2On->setOn(TRUE);
   }
   else
   {	   projector2PushButton->setPixmap( image1); 
           p2State = 0;
           p2Off->setOn(TRUE);
   }
   update();
}


void MainForm::projector3Clicked()
{
   if( p3State == 0)
   {	   projector3PushButton->setPixmap( image2); 
           p3State = 1;
           p3On->setOn(TRUE);
   }
   else
   {	   projector3PushButton->setPixmap( image1); 
           p3State = 0;
           p3Off->setOn(TRUE);
   }
   update();
}


void MainForm::projector1On()
{
   p1State = 0;
   projector1Clicked();
}


void MainForm::projector1Off()
{

   p1State = 1;
   projector1Clicked();
}


void MainForm::projector2Off()
{

   p2State = 1;
   projector2Clicked();
}


void MainForm::projector2On()
{
   p2State = 0;
   projector2Clicked();

}


void MainForm::projector3On()
{
   p3State = 0;
   projector3Clicked();
}


void MainForm::projector3Off()
{
   p3State = 1;
   projector3Clicked();
}


void MainForm::stageLightsClicked()
{

}





void MainForm::doClick( bool tristate, int* state, QPushButton * button )
{

		//change the state and the picture
		switch( *state )
		{
			case 0: 
				if( !tristate)
				{
					*state= 2;
					button->setPixmap(up);
					break;
				}
				(*state)++;		
				button->setPixmap(middle);
				break;
			case 1: 
				(*state)++;
				button->setPixmap(up);
				break;
			case 2: 
				*state = 0;
				button->setPixmap(down);
				break;
		}
}
