/****************************************************************************
** Form interface generated from reading ui file 'mainform.ui'
**
** Created: Mon Feb 21 02:05:56 2005
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.3   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef MAINFORM_H
#define MAINFORM_H

#include <qvariant.h>
#include <qpixmap.h>
#include <qmainwindow.h>
#include "instructorform.h"
#include "aboutform.h"
#include "rowdialogue.h"

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QAction;
class QActionGroup;
class QToolBar;
class QPopupMenu;
class QFrame;
class QPushButton;
class QButtonGroup;
class QLabel;
class QSlider;
class QString;
class rowDialogue;

class MainForm : public QMainWindow
{
    Q_OBJECT

public:
    MainForm( QWidget* parent = 0, const char* name = 0, WFlags fl = WType_TopLevel );
    ~MainForm();

    QFrame* frame16;
    QPushButton* projector1PushButton;
    QPushButton* projector2PushButton;
    QPushButton* projector3PushButton;
    QFrame* instructFrame;
    QPushButton* yangPushButton;
    QPushButton* yingPushButton;
    QButtonGroup* computerRowsButtonGroup;
    QPushButton* firstRowComputers;
    QPushButton* secondRowPushbutton;
    QPushButton* fifthRowPushButton;
    QPushButton* fourthRowPushButton;
    QPushButton* thirdRowPushButton;
    QFrame* frame17;
    QLabel* textLabel7;
    QFrame* line3;
    QFrame* line4;
    QLabel* textLabel6;
    QLabel* textLabel8;
    QSlider* stageLightsSlider;
    QPushButton* studentLightsPushButton;
    QPushButton* backLightsPushButton;
    QMenuBar *MenuBar;
    QPopupMenu *fileMenu;
    QPopupMenu *Computer;
    QPopupMenu *popupMenu_4;
    QPopupMenu *popupMenu_14;
    QPopupMenu *Projector;
    QPopupMenu *popupMenu_20;
    QPopupMenu *popupMenu_23;
    QPopupMenu *popupMenu_26;
    QPopupMenu *Lights;
    QPopupMenu *popupMenu_29;
    QPopupMenu *popupMenu_32;
    QPopupMenu *popupMenu_36;
    QPopupMenu *helpMenu;
    QAction* fileExitAction;
    QAction* editFindAction;
    QAction* helpAboutAction;
    QAction* computerStudentAction;
    QAction* computerStudentBack_RowAction;
    QAction* computerStudent4throwAction;
    QAction* computerStudent3rd_RowAction;
    QAction* computerStudent2nd_RowAction;
    QAction* computerStudentFront_RowAction;
    QAction* computerInstructorAction;
    QAction* computerInstructorYingAction;
    QAction* computerInstructorYangAction;
    QActionGroup* p1ProjectorDDgroup;
    QAction* p1On;
    QAction* p1Off;
    QActionGroup* p2ProjectorDDgroup;
    QAction* p2On;
    QAction* p2Off;
    QActionGroup* p3ProjectorDDgroup;
    QAction* p3On;
    QAction* p3Off;
    QActionGroup* BackRowLights;
    QAction* brOn;
    QAction* brOff;
    QActionGroup* StudentsLights;
    QAction* slMax;
    QAction* slMed;
    QAction* slOff;
    QActionGroup* stageLights;
    QAction* stOn;
    QAction* st90;
    QAction* st80;
    QAction* st70;
    QAction* st60;
    QAction* st50;
    QAction* st40;
    QAction* st30;
    QAction* st20;
    QAction* st10;
    QAction* stOff;

    QPixmap up;
    QString allComps[5][4];
    QPixmap projectorOn;
    QPixmap down;
    QPixmap middle;

public slots:
    virtual void fileOpen();
    virtual void fileSave();
    virtual void fileSaveAs();
    virtual void filePrint();
    virtual void fileExit();
    virtual void editUndo();
    virtual void editRedo();
    virtual void editCut();
    virtual void editCopy();
    virtual void editPaste();
    virtual void editFind();
    virtual void helpIndex();
    virtual void helpContents();
    virtual void helpAbout();
    virtual void fourthRowClicked();
    virtual void fifthRowClicked();
    virtual void thirdRowClicked();
    virtual void secondRowClicked();
    virtual void firstRowClicked();
    virtual void backLightsClicked();
    virtual void studentLightsClicked();
    virtual void setValue(int value);
    virtual void stageLightsOff();
    virtual void stageLights10();
    virtual void stageLights20();
    virtual void stageLights30();
    virtual void stageLights40();
    virtual void stageLights50();
    virtual void stageLights60();
    virtual void stageLights70();
    virtual void stageLights80();
    virtual void stageLights90();
    virtual void stageLightsMax();
    virtual void studentLightsMax();
    virtual void studentLightsMed();
    virtual void studentLightsOff();
    virtual void backLightsOn();
    virtual void backLightsOff();
    virtual void yangComputer();
    virtual void yingComputer();
    virtual void projector1Clicked();
    virtual void projector2Clicked();
    virtual void projector3Clicked();
    virtual void projector1On();
    virtual void projector1Off();
    virtual void projector2Off();
    virtual void projector2On();
    virtual void projector3On();
    virtual void projector3Off();
    virtual void stageLightsClicked();

signals:
    void instructorCompSelected(QString nameComp);

protected:

protected slots:
    virtual void languageChange();

private:
    QPixmap image0;
    QPixmap image1;
    QPixmap image2;
    QPixmap image3;
    QPixmap image4;
    QPixmap image5;
    QPixmap image6;
    QPixmap image7;
    QPixmap image8;
    QPixmap image9;
    QPixmap image10;
    QPixmap image11;

    void init();
    virtual void doClick( bool tristate, int* state, QPushButton * button );

};

#endif // MAINFORM_H
