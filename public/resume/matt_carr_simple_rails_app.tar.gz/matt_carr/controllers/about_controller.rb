#this is called the aboutcontroller simply
#because it is the best page on which to 
#illustrate this code

class AboutController < ApplicationController

  @questions #question array for ruby template
  @answers   #answer array 

  def index
  end

  #Open the txt file and fill the arrays
  #finally use the ooga object to process
  #and parse the correct format
  def initialize 
    f = File.new("inputfile.txt", "r")
    myooga = Ooga.new
    while( line = f.gets)
      type = line[0,1].upcase
      if( type == "A")
        myooga.addAnswer(line)
      elsif( type == "Q")
        myooga.addQuestion(line)
      end
    end
    f.close
    @questions = myooga.getQuestions
    @answers = myooga.processAnswers
  end

  #Evaluate the form and email the results to the two
  #People involved
  def ooga_process
  #iterate thru answers. check if checkboxes. iterate thru checkboxes.
    i = 0
    @res = ""
    for q in @questions
      @res << q  + "<br>"
      if( params[i.to_s] == "group" + i.to_s )
        groupArray = params["group" + i.to_s].split(",") #add i here
        for g in groupArray
          if( params[g.to_s] == "on" )
            @res << g.to_s + "<br>"
          end
        end
      else
        @res << params[i.to_s] + "<br>" 
      end
      i = i + 1
    end
    Notifier.deliver_application_notification(@res)
  end

end
