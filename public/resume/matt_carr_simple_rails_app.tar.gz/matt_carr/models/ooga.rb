class Ooga
  @qArray #the array of questions parsed from the text file
  @aArray #The array of possible answers

  def initialize
    @qArray = Array.new
    @aArray = Array.new
  end

  #addQuestion adds a question from the textfile
  def addQuestion( question )
    question[0..1] = ''
    @qArray << question
  end

  #addAnswer adds a possible SET of answers to the array
  def addAnswer( answer )
    answer[0..1] = ''
    @aArray << answer 
  end

  def getQuestions
    @qArray
  end

  #iterates through the answer array and
  #determines whether the possible answers
  #should be formatted as a Radio button, checkbox
  #or text
  def processAnswers
    i = 0
    for a in @aArray
      if( a.rindex(" or ") != nil )
        parseRadioButton(a, i)
      elsif( a.rindex("/") != nil )
        parseCheckList(a, i)
      elsif( a.rindex("text") != nil )
        parseText(a, i)
      end
      i = i + 1
    end
    @aArray
  end

  #Seperates input "text" by each " or " and returns a set of
  #radio buttons
  def parseRadioButton(text, i)
    #case 1 Radio buttons - contains " or "
    res = ""
    rArray = text.split(" or ")
    for val in rArray
      res <<  '<input type="radio" name="' + i.to_s + '" value="' + val + '">' + val + '<br>' 
    end
    @aArray[i] = res
  end

  #Seperates the "text" by "/" and creates a checklist group
  #set.
  def parseCheckList(text, i)
    #case 2 Checklist - contains "/"
    rArray = text.split("/")
    hidden = '<input type="hidden" name="group' + i.to_s + '" value="'
    res = '<input type="hidden" value="group' + i.to_s + '" name="' + i.to_s + '"><br>'
    for val in rArray
      res << '<input type="checkbox" name="' + val + '">' + val + '<br>'
      hidden << val.chomp + ","
    end
    hidden = hidden.chomp(',') + '">'
    res << hidden
    @aArray[i] = res 
  end
 
  #returns a text box entry input
  def parseText(text, i)
    #case 3 textbox - contains "text"
    @aArray[i] = '<input type="text" name="' + i.to_s + '">'
  end

end 
