class Notifier < ActionMailer::Base

   #Send the job applications to me and someone else
   #if needed.
   def application_notification(info)
     recipients "Matt Carr " + "<bikokid@gmail.com>"
     from       "Elleander Grey <elleande@otus.site5.com>"
     subject    "Job Application results"
     body       "results" => info
   end

end
