/****************************************************************************
** Form interface generated from reading ui file 'options.ui'
**
** Created: Sun Oct 9 06:38:24 2005
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.3   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef OPTIONSDIALOG_H
#define OPTIONSDIALOG_H

#include <qvariant.h>
#include <qdialog.h>
#include <qguardedptr.h>
#include <qvbox.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QLineEdit;
class QToolButton;
class QLabel;
class QSlider;
class QPushButton;

class OptionsDialog : public QDialog
{
    Q_OBJECT

public:
    OptionsDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~OptionsDialog();

    QGroupBox* gbLadspa;
    QLineEdit* LEwavFile;
    QToolButton* tbPickWavfile;
    QLabel* TLwavFile;
    QSlider* SLfx1;
    QSlider* SLfx1_11;
    QSlider* SLfx1_9;
    QSlider* SLfx1_7;
    QSlider* SLfx1_6;
    QSlider* SLfx1_5;
    QSlider* SLfx1_4;
    QSlider* SLfx1_3;
    QSlider* SLfx1_8;
    QSlider* SLfx1_3_2_2;
    QSlider* SLfx1_3_2_3;
    QSlider* SLfx1_3_2_4;
    QSlider* SLfx1_2;
    QSlider* SLfx1_10;
    QLabel* valueOnetext;
    QSlider* SLfx1_3_2;
    QPushButton* pbApply;
    QPushButton* pbClose;

public slots:
    virtual void apply();
    virtual void SLfx1_valueChanged( int fval );

protected:
    QVBoxLayout* OptionsDialogLayout;
    QHBoxLayout* layout2;
    QHBoxLayout* layout1;
    QSpacerItem* spacer1;

protected slots:
    virtual void languageChange();

    virtual void pickIcon();


private:
    QGuardedPtr<QVBox> widget;

};

#endif // OPTIONSDIALOG_H
