/****************************************************************************
** Form implementation generated from reading ui file 'options.ui'
**
** Created: Sun Oct 9 06:38:31 2005
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.3   edited Nov 24 2003 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "options.h"

#include <qvariant.h>
#include <qfiledialog.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qlineedit.h>
#include <qtoolbutton.h>
#include <qlabel.h>
#include <qslider.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include "options.ui.h"

/*
 *  Constructs a OptionsDialog as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
OptionsDialog::OptionsDialog( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "OptionsDialog" );
    OptionsDialogLayout = new QVBoxLayout( this, 11, 6, "OptionsDialogLayout"); 

    gbLadspa = new QGroupBox( this, "gbLadspa" );
    gbLadspa->setFlat( TRUE );

    QWidget* privateLayoutWidget = new QWidget( gbLadspa, "layout2" );
    privateLayoutWidget->setGeometry( QRect( 98, 24, 240, 27 ) );
    layout2 = new QHBoxLayout( privateLayoutWidget, 11, 6, "layout2"); 

    LEwavFile = new QLineEdit( privateLayoutWidget, "LEwavFile" );
    layout2->addWidget( LEwavFile );

    tbPickWavfile = new QToolButton( privateLayoutWidget, "tbPickWavfile" );
    layout2->addWidget( tbPickWavfile );

    TLwavFile = new QLabel( gbLadspa, "TLwavFile" );
    TLwavFile->setGeometry( QRect( 11, 24, 81, 27 ) );

    SLfx1 = new QSlider( gbLadspa, "SLfx1" );
    SLfx1->setGeometry( QRect( 98, 57, 240, 21 ) );
    SLfx1->setMinValue( 0 );
    SLfx1->setMaxValue( 100 );
    SLfx1->setPageStep( 10 );
    SLfx1->setValue( 50 );
    SLfx1->setOrientation( QSlider::Horizontal );
    SLfx1->setTickmarks( QSlider::Below );
    SLfx1->setTickInterval( 10 );

    SLfx1_11 = new QSlider( gbLadspa, "SLfx1_11" );
    SLfx1_11->setGeometry( QRect( 100, 110, 240, 21 ) );
    SLfx1_11->setMinValue( 0 );
    SLfx1_11->setMaxValue( 100 );
    SLfx1_11->setPageStep( 10 );
    SLfx1_11->setValue( 50 );
    SLfx1_11->setOrientation( QSlider::Horizontal );
    SLfx1_11->setTickmarks( QSlider::Below );
    SLfx1_11->setTickInterval( 10 );

    SLfx1_9 = new QSlider( gbLadspa, "SLfx1_9" );
    SLfx1_9->setGeometry( QRect( 100, 170, 240, 21 ) );
    SLfx1_9->setMinValue( 0 );
    SLfx1_9->setMaxValue( 100 );
    SLfx1_9->setPageStep( 10 );
    SLfx1_9->setValue( 50 );
    SLfx1_9->setOrientation( QSlider::Horizontal );
    SLfx1_9->setTickmarks( QSlider::Below );
    SLfx1_9->setTickInterval( 10 );

    SLfx1_7 = new QSlider( gbLadspa, "SLfx1_7" );
    SLfx1_7->setGeometry( QRect( 100, 230, 240, 21 ) );
    SLfx1_7->setMinValue( 0 );
    SLfx1_7->setMaxValue( 100 );
    SLfx1_7->setPageStep( 10 );
    SLfx1_7->setValue( 50 );
    SLfx1_7->setOrientation( QSlider::Horizontal );
    SLfx1_7->setTickmarks( QSlider::Below );
    SLfx1_7->setTickInterval( 10 );

    SLfx1_6 = new QSlider( gbLadspa, "SLfx1_6" );
    SLfx1_6->setGeometry( QRect( 100, 260, 240, 21 ) );
    SLfx1_6->setMinValue( 0 );
    SLfx1_6->setMaxValue( 100 );
    SLfx1_6->setPageStep( 10 );
    SLfx1_6->setValue( 50 );
    SLfx1_6->setOrientation( QSlider::Horizontal );
    SLfx1_6->setTickmarks( QSlider::Below );
    SLfx1_6->setTickInterval( 10 );

    SLfx1_5 = new QSlider( gbLadspa, "SLfx1_5" );
    SLfx1_5->setGeometry( QRect( 100, 290, 240, 21 ) );
    SLfx1_5->setMinValue( 0 );
    SLfx1_5->setMaxValue( 100 );
    SLfx1_5->setPageStep( 10 );
    SLfx1_5->setValue( 50 );
    SLfx1_5->setOrientation( QSlider::Horizontal );
    SLfx1_5->setTickmarks( QSlider::Below );
    SLfx1_5->setTickInterval( 10 );

    SLfx1_4 = new QSlider( gbLadspa, "SLfx1_4" );
    SLfx1_4->setGeometry( QRect( 100, 320, 240, 21 ) );
    SLfx1_4->setMinValue( 0 );
    SLfx1_4->setMaxValue( 100 );
    SLfx1_4->setPageStep( 10 );
    SLfx1_4->setValue( 50 );
    SLfx1_4->setOrientation( QSlider::Horizontal );
    SLfx1_4->setTickmarks( QSlider::Below );
    SLfx1_4->setTickInterval( 10 );

    SLfx1_3 = new QSlider( gbLadspa, "SLfx1_3" );
    SLfx1_3->setGeometry( QRect( 0, 100, 90, 21 ) );
    SLfx1_3->setMinValue( 0 );
    SLfx1_3->setMaxValue( 100 );
    SLfx1_3->setPageStep( 10 );
    SLfx1_3->setValue( 50 );
    SLfx1_3->setOrientation( QSlider::Horizontal );
    SLfx1_3->setTickmarks( QSlider::Below );
    SLfx1_3->setTickInterval( 10 );

    SLfx1_8 = new QSlider( gbLadspa, "SLfx1_8" );
    SLfx1_8->setGeometry( QRect( 100, 200, 240, 21 ) );
    SLfx1_8->setMinValue( 0 );
    SLfx1_8->setMaxValue( 100 );
    SLfx1_8->setPageStep( 10 );
    SLfx1_8->setValue( 50 );
    SLfx1_8->setOrientation( QSlider::Horizontal );
    SLfx1_8->setTickmarks( QSlider::Below );
    SLfx1_8->setTickInterval( 10 );

    SLfx1_3_2_2 = new QSlider( gbLadspa, "SLfx1_3_2_2" );
    SLfx1_3_2_2->setGeometry( QRect( 0, 160, 90, 21 ) );
    SLfx1_3_2_2->setMinValue( 0 );
    SLfx1_3_2_2->setMaxValue( 100 );
    SLfx1_3_2_2->setPageStep( 10 );
    SLfx1_3_2_2->setValue( 50 );
    SLfx1_3_2_2->setOrientation( QSlider::Horizontal );
    SLfx1_3_2_2->setTickmarks( QSlider::Below );
    SLfx1_3_2_2->setTickInterval( 10 );

    SLfx1_3_2_3 = new QSlider( gbLadspa, "SLfx1_3_2_3" );
    SLfx1_3_2_3->setGeometry( QRect( 0, 190, 90, 21 ) );
    SLfx1_3_2_3->setMinValue( 0 );
    SLfx1_3_2_3->setMaxValue( 100 );
    SLfx1_3_2_3->setPageStep( 10 );
    SLfx1_3_2_3->setValue( 50 );
    SLfx1_3_2_3->setOrientation( QSlider::Horizontal );
    SLfx1_3_2_3->setTickmarks( QSlider::Below );
    SLfx1_3_2_3->setTickInterval( 10 );

    SLfx1_3_2_4 = new QSlider( gbLadspa, "SLfx1_3_2_4" );
    SLfx1_3_2_4->setGeometry( QRect( 0, 220, 90, 21 ) );
    SLfx1_3_2_4->setMinValue( 0 );
    SLfx1_3_2_4->setMaxValue( 100 );
    SLfx1_3_2_4->setPageStep( 10 );
    SLfx1_3_2_4->setValue( 50 );
    SLfx1_3_2_4->setOrientation( QSlider::Horizontal );
    SLfx1_3_2_4->setTickmarks( QSlider::Below );
    SLfx1_3_2_4->setTickInterval( 10 );

    SLfx1_2 = new QSlider( gbLadspa, "SLfx1_2" );
    SLfx1_2->setGeometry( QRect( 100, 80, 240, 21 ) );
    SLfx1_2->setMinValue( 0 );
    SLfx1_2->setMaxValue( 100 );
    SLfx1_2->setPageStep( 10 );
    SLfx1_2->setValue( 50 );
    SLfx1_2->setOrientation( QSlider::Horizontal );
    SLfx1_2->setTickmarks( QSlider::Below );
    SLfx1_2->setTickInterval( 10 );

    SLfx1_10 = new QSlider( gbLadspa, "SLfx1_10" );
    SLfx1_10->setGeometry( QRect( 100, 140, 240, 21 ) );
    SLfx1_10->setMinValue( 0 );
    SLfx1_10->setMaxValue( 100 );
    SLfx1_10->setPageStep( 10 );
    SLfx1_10->setValue( 50 );
    SLfx1_10->setOrientation( QSlider::Horizontal );
    SLfx1_10->setTickmarks( QSlider::Below );
    SLfx1_10->setTickInterval( 10 );

    valueOnetext = new QLabel( gbLadspa, "valueOnetext" );
    valueOnetext->setGeometry( QRect( 0, 60, 81, 21 ) );

    SLfx1_3_2 = new QSlider( gbLadspa, "SLfx1_3_2" );
    SLfx1_3_2->setGeometry( QRect( 0, 130, 90, 21 ) );
    SLfx1_3_2->setMinValue( 0 );
    SLfx1_3_2->setMaxValue( 100 );
    SLfx1_3_2->setPageStep( 10 );
    SLfx1_3_2->setValue( 50 );
    SLfx1_3_2->setOrientation( QSlider::Horizontal );
    SLfx1_3_2->setTickmarks( QSlider::Below );
    SLfx1_3_2->setTickInterval( 10 );
    OptionsDialogLayout->addWidget( gbLadspa );

    layout1 = new QHBoxLayout( 0, 0, 6, "layout1"); 
    spacer1 = new QSpacerItem( 70, 21, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout1->addItem( spacer1 );

    pbApply = new QPushButton( this, "pbApply" );
    pbApply->setDefault( TRUE );
    layout1->addWidget( pbApply );

    pbClose = new QPushButton( this, "pbClose" );
    layout1->addWidget( pbClose );
    OptionsDialogLayout->addLayout( layout1 );
    languageChange();
    resize( QSize(371, 482).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( pbClose, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( pbApply, SIGNAL( clicked() ), this, SLOT( apply() ) );
    connect( tbPickWavfile, SIGNAL( clicked() ), this, SLOT( pickIcon() ) );
    connect( SLfx1, SIGNAL( valueChanged(int) ), this, SLOT( SLfx1_valueChanged(int) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
OptionsDialog::~OptionsDialog()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void OptionsDialog::languageChange()
{
    setCaption( tr( "Select Options" ) );
    gbLadspa->setTitle( tr( "Properties" ) );
    QWhatsThis::add( gbLadspa, tr( "Set other properties of the window." ) );
    QToolTip::add( LEwavFile, tr( "Icon file" ) );
    QWhatsThis::add( LEwavFile, tr( "Provide an image file." ) );
    tbPickWavfile->setText( tr( "..." ) );
    QToolTip::add( tbPickWavfile, tr( "Pick an icon" ) );
    QWhatsThis::add( tbPickWavfile, tr( "Select an image file." ) );
    TLwavFile->setText( tr( "Wav File:" ) );
    QToolTip::add( SLfx1, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_11, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_11, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_9, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_9, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_7, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_7, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_6, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_6, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_5, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_5, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_4, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_4, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_3, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_3, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_8, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_8, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_3_2_2, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_3_2_2, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_3_2_3, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_3_2_3, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_3_2_4, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_3_2_4, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_2, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_2, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    QToolTip::add( SLfx1_10, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_10, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    valueOnetext->setText( tr( "Input Values" ) );
    QToolTip::add( SLfx1_3_2, tr( "Window transparency" ) );
    QWhatsThis::add( SLfx1_3_2, tr( "Set the transparency of the window.\n"
"A high value gives a high window transparency, e.g. it is less visible.\n"
"\n"
"Note that this attribute is not supported on many windowing systems and will have no effect." ) );
    pbApply->setText( tr( "Apply" ) );
    pbApply->setAccel( QKeySequence( QString::null ) );
    QWhatsThis::add( pbApply, tr( "Creates a new window with the selected flags, or modifies the visible window." ) );
    pbClose->setText( tr( "Close" ) );
    pbClose->setAccel( QKeySequence( QString::null ) );
    QWhatsThis::add( pbClose, tr( "Closes this dialog and exits the application." ) );
}

